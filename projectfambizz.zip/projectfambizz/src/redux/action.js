function testAction(post) {
    return {
        type: "TEST_ACTION",
        payload: { text: post.text }
    }
}

export { testAction }