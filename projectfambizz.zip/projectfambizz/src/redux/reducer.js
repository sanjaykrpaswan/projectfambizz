import { combineReducers } from 'redux'


const testReducer = (state = [], action) => {
    switch (action.type) {
        case "TEST_ACTION":
            return [...state, { text: action.payload.text}]
        default: return state
    }
}

const rootReducer = combineReducers({
    test: testReducer
});

export default rootReducer;