import {useEffect, useRef} from 'react';
import type {AxiosInstance} from 'axios';
import axios from "axios";


import { useAuth } from "react-oidc-context";

export const useAxios = () => {
    
    const axiosInstance = useRef<AxiosInstance>();
   
    const auth = useAuth();
    const kcToken = auth.user?.access_token ?? '';;
    const authenticated = auth.isAuthenticated;
    
    const checkpointUrgency = authenticated;

    useEffect(() => {
        
        function cleanUp() {
            console.log('clean up (axios) instance.');
            return () => axiosInstance.current = undefined;
        }

        function setAxiosInstance() {
            console.log('Setting HTTP client (axios) instance.');
            axiosInstance.current = axios.create({
                baseURL: process.env.REACT_APP_URL,
                timeout: Number(process.env.REACT_APP_API_TIME_OUT_IN_MS),
                headers: {
                    Authorization: authenticated ? `Bearer ${kcToken}` : "",
                },
            });
        }

        setAxiosInstance();

        if (!checkpointUrgency) return cleanUp();
        
        

    }, [kcToken, checkpointUrgency, authenticated]);

    return axiosInstance;
};