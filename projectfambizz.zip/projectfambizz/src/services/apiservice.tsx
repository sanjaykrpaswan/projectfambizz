import { APIURLS } from "../common/constants"


class apiservice {

  static DataCollection = class {
    static getAssetDetailsList() {
      return `${APIURLS.RFManageCollectionData}${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getAssetById(id: any) {
      return `${APIURLS.GetAssetById}${id}&tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }
  }

  static Portal = class {
    static getPortalData() {
      return `${APIURLS.Portal}?tenantName=${localStorage.getItem("tanentName")}`;
    }
  }

  static Audit = class {
    static auditDetails(name: any, value_Id: any, tenant_Id: any) {
      return `${APIURLS.AuditDetails}?auditMasterName=${name}&itemId=${value_Id}&tenantId=${tenant_Id}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static auditDetailsByParentId(name: any, parentId: any, tenantId: any) {
      return `${APIURLS.AuditDetailsBasedOnParent}?auditMasterName=${name}&tenantId=${tenantId}&parentId=${parentId}&tenantName=${localStorage.getItem("tanentName")}`
    }
    
    static auditUserList(name: any) {
      return `${APIURLS.AuditUserList}?auditMasterName=${name}&tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static auditFieldsList(name: any) {
      return `${APIURLS.AuditFieldsList}?auditMasterName=${name}&tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }
  }  

  static SettingsResourceType = class {
    static getResourceTypelist(tenantId: any) {
      return `${APIURLS.ResourceTypeList}${tenantId}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getEmissionAndAssetTypelist() {
      return `${APIURLS.GetEmissionAndAssetTypeDetails}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static viewResourceType(id: any) {
      return `${APIURLS.ResourceTypeUrl}/${id}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static deleteResourceType(id: any){
      return `${APIURLS.DeleteResourceType}${id}&tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem(
          "tanentName")}`
    }

    static createResourceType(){
      return `${APIURLS.ResourceTypeUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static updateResourceType(){
      return `${APIURLS.ResourceTypeUrl}?tenantName=${localStorage.getItem("tanentName")}` 
    }
    
  };

  static SettingsUnits = class {

    static getUnitsList() {
        return `${APIURLS.UnitsList}${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getUnitById(id: any) {
      return `${APIURLS.UnitUrl}/${id}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static deleteUnitById(id: any) {
      return `${APIURLS.UnitUrl}/${id}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static updateUnitById() {
      return `${APIURLS.UnitUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static createUnit() {
      return `${APIURLS.UnitUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }

  }

  static SettingsUnitGroups = class {
    static getUnitGroupsList() {
      return `${APIURLS.UnitGroupsList}${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getUnitListByUnitGroupId(unitGroupId: any) {
      return `${APIURLS.GetUnitListByUnitGroupId}${unitGroupId}&tenantName=${localStorage.getItem("tanentName")}`
    }


    static getUnitGroupById(id: any) {
      return `${APIURLS.UnitGroupUrl}/${id}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static createUnitGroup() {
      return `${APIURLS.UnitGroupUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static updateUnitGroupById() {
      return `${APIURLS.UnitGroupUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }


    static deleteUnitGroupById(id: any) {
      return `${APIURLS.UnitGroupUrl}/${id}?tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

  }

  static SettingsAssetCategory = class {
    static getAssetDetails() {
      return `${APIURLS.AssetCategoryUrl}${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getAssetResourceByCategoryId(id: any) {
      return `${APIURLS.GetAssetResourceByCategoryId}${id}&tenantId=${localStorage.getItem(
          "tenantId"
        )}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getSubCategoryDetailsById(id: any , assetCategoryId: any) {
      return `${APIURLS.GetSubCategoryDetails}${id}&assetCategoryId=${assetCategoryId}&tenantId=${localStorage.getItem(
          "tenantId"
        )}&tenantName=${localStorage.getItem("tanentName")}`
    }
  }

  static SettingsCurrency = class {
    static getCurrencyList() {
        return `${APIURLS.CurrencyList}${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static getCurrecyById(id: any) {
      return `${APIURLS.CurrencyUrl}/${id}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static deleteCurrencyById(id: any) {
      return `${APIURLS.CurrencyUrl}/${id}?tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }

    static updateCurrencyById() {
      return `${APIURLS.CurrencyUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static createCurrency() {
      return `${APIURLS.CurrencyUrl}?tenantName=${localStorage.getItem("tanentName")}`
    }

    static getCurrencyConversionDetails(id: any) {
      return `${APIURLS.GetCurrencyConvesionDetails}/${id}?tenantId=${localStorage.getItem("tenantId")}&tenantName=${localStorage.getItem("tanentName")}`
    }
  }

}
export default apiservice;