import { useAuth } from "react-oidc-context";

const auth = useAuth();


const token = auth.user?.access_token;

const doLogin = auth.signinRedirect();

const doLogout = () => auth.signoutRedirect();

const getToken = () => token;
const getRefreshToken = () => auth.user?.refresh_token;
const isLoggedIn = () => !!token;

const updateToken = () =>{
  console.log("need to updat")
}
    

const getUsername = () => auth.user?.profile?.preferred_username;
const getUserDetail = () => auth.user?.profile?.idTokenParsed;
const clientKey = () => auth.user?.profile?.clientKey;
const locale = () => auth.user?.profile?.locale;
const puid = () => auth.user?.profile?.puid;


const UserService = {
    doLogin,
  doLogout,
  isLoggedIn,
  getToken,
  updateToken,
  getUsername,
   getUserDetail,
  getRefreshToken,
  locale,
  puid,
  clientKey
};

export default UserService;