export const loadScript = (scriptTagId: string, scriptUrl: string): Promise<void>  => {
    return new Promise(resolve => {
      const scriptTag = document.createElement('script')
      scriptTag.id = scriptTagId
      scriptTag.src = scriptUrl
      scriptTag.async = true
      scriptTag.onload = () => { resolve() }
      scriptTag.onerror = () => { console.error(`Could not load ${scriptUrl}`) }
      document.head.appendChild(scriptTag)
    })
  }