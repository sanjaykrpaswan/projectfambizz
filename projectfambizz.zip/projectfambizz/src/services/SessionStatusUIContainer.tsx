import React, { useEffect } from 'react';
import { ISessionStatusUIOptions } from './ISessionStatusUIOptions';
import { loadScript } from './loadScript';
import UserService from './userService';


declare const Navex: any


export const SessionStatusUIContainer = (props:any) => {
  const divId = 'session_status_ui'

  useEffect(() => {
    injectSessionStatusUI()
  }, // eslint-disable-next-line
    [])

  const injectSessionStatusUI = async () => {
     let url = process.env.REACT_APP_MOON_WATCH_SCRIPT_URL
     console.log("url=>" + url)
    await loadScript('session-status-id-script', url== undefined?'':url)
    const sessionStatusUIOptions: ISessionStatusUIOptions = {
        divId,
        clientKey: UserService.clientKey,
        lang: UserService.locale,
        puid: UserService.puid,

        logoutCallback: () => {
            UserService.doLogout();
        },
        onGetAuthTokenFromHostApp: function (): string | Promise<string> | undefined {
            //throw new Error('Function not implemented.');
            return UserService.isLoggedIn() ? UserService.getToken() : undefined;
        }
    }
    Navex.SessionStatusUI.inject(sessionStatusUIOptions)
  }

  return (
    <div id={divId}></div>
  )
}