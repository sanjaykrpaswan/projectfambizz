// This should match the interface from here:
// https://github.com/tnwinc/session-status-ui/edit/develop/src/interfaces/ISessionStatusUIOptions.d.ts
export interface ISessionStatusUIOptions {
    // Required props
    divId: string
    puid: any
    lang: any
    clientKey: any
    sessionTimeoutSeconds?: number,
    onGetAuthTokenFromHostApp: () => string | Promise<string> | undefined
    logoutUrl?: string
    logoutCallback?: (e: any) => void
  }