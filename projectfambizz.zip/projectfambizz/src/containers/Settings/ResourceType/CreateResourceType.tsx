import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, FormikInput, FormikSelect, FormikOption, Toasts } from 'navex-react'
import './ResourceType.css'
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { useHistory } from 'react-router-dom';
import { Formik, Form, Field } from 'formik'
import { useEffect, useState } from 'react';
import Loader from '../../../common/loader/Loader';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const ResourceAddSchema = Yup.object().shape({
    resourceName: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
    assetType: Yup.string().required('field is required'),
    emissionScope: Yup.string().required('field is required'),
    abbreviation: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('field is required'),

})

const CreateResourceType = (props: any) => {

    const [emissionData, setEmissionData] = useState<any[]>([])
    const [assetTypeData, setAssetTypeData] = useState<any[]>([])
    const [submitClicked,setSubmitClicked] =useState(false)
    const axiosInstance = useAxios();

    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/resourceType`);
    }

    /** API call to create the resourceType */
    const handleResourceSubmit = async (value: any, actions : any) => {
        setSubmitClicked(true);
        const payload = {
            name : value.resourceName,
            abbreviation : value.abbreviation,
            isDeleted : false,
            assetTypeId : Number(value.assetType),
            emissionId : Number(value.emissionScope),
            tenantId : Number(localStorage.getItem("tenantId"))    
        }
        const response = await axiosInstance.current?.post(apiservice.SettingsResourceType.createResourceType(),payload);
        if (response?.status === RESPONSE_STATUS.success) {
            Toasts.success("Successfully created Resource Type");
            cancelHandler();
        } else if(response?.status === 406){
        setSubmitClicked(false);
        Toasts.alert(response.data.message, {autoClose:3000});
            actions.resetForm();
        }
        else {
            Toasts.alert(response?.data.message);
        }

    }



    /** API call to get the list of asset type and emission */
    const getDropdownList = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsResourceType.getEmissionAndAssetTypelist());
        if (response?.status === RESPONSE_STATUS.success) {
            
            setEmissionData(response.data.data.emissionScope.sort((a: any, b: any) => a.name.localeCompare(b.name)))
            setAssetTypeData(response.data.data.assetType.sort((a: any, b: any) => a.type.localeCompare(b.type)))

        }
        else {
            Toasts.alert(response?.data.message);
        }
    }

    useEffect(() => {
        getDropdownList();
    }, [])



    return (

        <>
            {!(emissionData && assetTypeData && (submitClicked === false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Resource Type</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'> Add Resource Type: </h3>
                        <div className="form">
                            <Row style={{ textAlign: 'left' }}>
                                <Formik
                                    initialValues={{
                                        assetType: '',
                                        emissionScope: '',
                                        resourceName: '',
                                        abbreviation: '',
                                        submit: true,
                                    }}
                                    validationSchema={ResourceAddSchema}
                                    onSubmit={handleResourceSubmit}
                                >
                                    <Form style={{ width: '500px' }}>

                                        <Field
                                            name='assetType'
                                            label='Asset Type'
                                            required
                                            defaultTitle='Select Asset Type'
                                            component={FormikSelect}
                                            maxMenuHeight={'50px' && '186px'}
                                        >
                                            {assetTypeData.map((prov): any => (
                                                <FormikOption value={prov.id}>{prov.type}</FormikOption>
                                            ))}

                                        </Field>

                                        <Field
                                            name='emissionScope'
                                            label='Emission Scope'
                                            required
                                            defaultTitle='Select Emission Type'
                                            component={FormikSelect}
                                            maxMenuHeight={'50px' && '186px'}
                                        >
                                            {emissionData.map((prov): any => (
                                                <FormikOption value={prov.id}>{prov.name}</FormikOption>
                                            ))}


                                        </Field>


                                        <Field
                                            name='resourceName'
                                            required
                                            label='Resource Name'
                                            component={FormikInput}

                                        />


                                        <Field
                                            name='abbreviation'
                                            required
                                            label='Abbreviation'
                                            component={FormikInput}

                                        />

                                        <Row style={{ marginTop: "16px" }}>
                                            <Col size={12} sm={12}>
                                                <ButtonRow alignment="right">
                                                    <Button
                                                        purpose="default"
                                                        onClick={cancelHandler}
                                                    >
                                                        Cancel
                                                    </Button>
                                                    <Button id="save" type="submit" purpose="primary" >
                                                        Save
                                                    </Button>
                                                </ButtonRow>
                                            </Col>
                                        </Row>

                                    </Form>
                                </Formik>

                            </Row>

                        </div>
                    </div>
                </div>

            )}
        </>

    )
}

export default CreateResourceType


