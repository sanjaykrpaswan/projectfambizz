import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, Toasts, Accordion, Card } from 'navex-react'
import './ResourceType.css'
import { useHistory } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Loader from '../../../common/loader/Loader';
import "../../../styles/styles.css";
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import {AuditGrid} from '../Audit/AuditGrid';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";


const ViewResourceType = (props: any) => {

    const axiosInstance = useAxios();
    const [resourcetypeData, setResourcetypeData] = useState<any>();
    const [auditDetails, setAuditDetails] = useState<any>();
    let tenantId = localStorage.getItem("tenantId");

    /** API call to get the details of resource type */
    const getResourceType = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsResourceType.viewResourceType(id));
        if (response?.status === RESPONSE_STATUS.success) {
            setResourcetypeData(response.data.data)
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }
    }

    /** API call to get the audit details of resource type */
    const getAuditDetails = async () => {
        const response = await axiosInstance.current?.get(apiservice.Audit.auditDetails("asset_resource", id, tenantId));
        if (response?.status === RESPONSE_STATUS.success) {
            response?.data?.data?.map((item: any) => {
                item.tempOldValue = JSON.stringify(item.oldValue)
                item.tempNewValue = JSON.stringify(item.newValue)
            })
            setAuditDetails(response.data.data);
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }
    }

    useEffect((() => {
        getResourceType();
        getAuditDetails();
    }), [])

    let temp: any;
    if(props.location.state === undefined){
        temp = window.localStorage.getItem("resourceTypeId");
    }
    const id = (temp !== undefined ? JSON.parse(temp) : props.location.state.id);

    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/resourceType`);
    }

    const editHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/resourceType/editResourceType`, { resourceTypeId: id });
    }

    return (
        <>
            {!(resourcetypeData) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (


                <div>
                    <h1 className="esg-page-heading">Resource Type</h1><hr className="line" /><div className="all-page-container">
                        <div style={{ marginTop: '15px' }}>

                            <Row className='view-resource-info'>
                                <Col className="sd-label" size={12} sm={2}>Resource Name</Col>
                                <Col style={{ borderTop: '0px' }}>{resourcetypeData.name}</Col>
                            </Row>
                            <Row className='view-resource-info'>
                                <Col className="sd-label" size={12} sm={2}>Abbreviation</Col>
                                <Col style={{ borderTop: '0px' }}>{resourcetypeData.abbreviation}</Col>
                            </Row>
                            <Row className='view-resource-info'>
                                <Col className="sd-label" size={12} sm={2}>Asset Type</Col>
                                <Col style={{ borderTop: '0px' }}>{resourcetypeData.assetType}</Col>
                            </Row>
                            <Row className='view-resource-info'>
                                <Col className="sd-label" size={12} sm={2}>Emission Scope</Col>
                                <Col style={{ borderTop: '0px' }}>{resourcetypeData.emissionName}</Col>
                            </Row>


                        </div>
                        <div>
                            <ButtonRow alignment='right'>


                                <Button purpose='default' onClick={cancelHandler}>Cancel</Button>
                                <Button purpose='primary' onClick={editHandler}>Edit</Button>

                            </ButtonRow>
                        </div>
                        <div>
                        <div style={{marginTop:"20px"}}>
                            <AuditGrid props={auditDetails} location = {props.location.pathname}/>
                            </div>
                        </div>
                    </div>
                </div>
            )}


        </>
    )

}

export default ViewResourceType


