import "./ResourceType.css";
import { FC, useEffect, useState } from "react";
import Card from "reactstrap/lib/Card";
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { ActionIcon, Button, dxReactGrid, Toasts } from "navex-react";
import 'devextreme/dist/css/dx.light.css';
import { useHistory } from 'react-router-dom';
import { faEye, faPencilAlt, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { Helmet } from "react-helmet";
import "../../../styles/styles.css";
import PopUpModal from "../../../common/PopUp/PopUpModal";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import Loader from "../../../common/loader/Loader";
import { APIURLS } from "../../../common/constants";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";


const { ResetGridModal, TableHeaderNavbar } = dxReactGrid;



export const Settings: FC<any> = (props: any) => {

  const history = useHistory();

  const [text, setText] = useState<any>()
  const axiosInstance = useAxios();
  const [loadResourceList, setLoadResourceList] = useState(false);
  const [resetGridModal, setResetGridModal] = useState(false);
  const [resourceData, setresourceData] = useState<any>([]);
  const [resourceId, setResourceId] = useState<any>();
  let tenantId = localStorage.getItem("tenantId");
  const [showModal, setShowModal] = useState(false);
  const open = (id: any) => {
    setShowModal(true);
    setResourceId(id);
  }

  const close = () => setShowModal(false);

  /** API call to get the list of resource type */
  const manageData = async () => {
    setLoadResourceList(true);
    const response = await axiosInstance.current?.get(apiservice.SettingsResourceType.getResourceTypelist(tenantId))
    if (response?.status === RESPONSE_STATUS.success) {

      setresourceData(response.data.data)
      setLoadResourceList(false);
    } else {
      Toasts.alert(response?.data.message);
    }

  }

  useEffect((() => {
    manageData();
  }), [])

  const toggleResetGridModal = () => {
    setResetGridModal(!resetGridModal);
  };



  const viewResourceTypeHandler = (id: any) => {
    window.localStorage.setItem("resourceTypeId", id);
    history.push(`/esg/${localStorage.getItem("tanentName")}/settings/resourceType/viewResourceType`, { id: id });
  }

  const editResourceTypeHandler = (id: any) => {
    window.localStorage.setItem("resourceTypeId", id);
    history.push(`/esg/${localStorage.getItem("tanentName")}/settings/resourceType/editResourceType`, { resourceTypeId: id });
  }

  const addHandler = () => {
    history.push(
      `/esg/${localStorage.getItem("tanentName")}/settings/resourceType/newResourceType`
    );
  };

  const handleClickedCancel = () => {
    close();
  }

  /** API call to delete the resourceType */
  const handleClickedOk = async () => {
    close();
    const response = await axiosInstance.current?.delete(apiservice.SettingsResourceType.deleteResourceType(resourceId));
    if (response?.status === RESPONSE_STATUS.success) {

      Toasts.success("Successfully deleted Resource Type", { autoClose: 3000 });
      manageData();

    } else {
      Toasts.alert("Failed to delete the Resource Type", { autoClose: 3000 });
    }
  }

  /** Functional component to render action icons in each row of the grid */

  const EditDeleteActionIcons = (id: any) => {
    return (
      <>
        <div>

          <ActionIcon
            id="view"
            icon={faEye}
            toolTip="View"
            disabled={false}
            data-toggle="modal"
            onClick={() => { viewResourceTypeHandler(id) }}
          >

          </ActionIcon>

          <ActionIcon
            id="edit"
            icon={faPencilAlt}
            toolTip="Edit"
            disabled={false}
            data-toggle="modal"
            onClick={() => { editResourceTypeHandler(id) }}
          />

          <ActionIcon
            id="deleteGroup"
            icon={faTrashAlt}
            toolTip="Delete"
            disabled={false}
            data-toggle="modal"
            onClick={() => open(id)}

          />
        </div>
      </>
    );

  };

  return (
    <>

      <Helmet><title>Settings - NAVEX ESG</title></Helmet>
      <h1 className="esg-page-heading">Resource Type</h1>
      <hr className="line" />
      <div className="all-page-container ">
        {loadResourceList ? <Loader style={{ left: "45%", right: "50%", marginTop: "10%" }} /> : (

          <>
            <Button
              style={{ float: "right", marginTop: "15px" }}
              purpose="primary"
              onClick={addHandler}
            >
              Add 
            </Button>



            <Card className="dx-nsg-react-grid survey-table-root dataGrid-card-noheader" style={{ marginTop: "55px" }}>
              <div className="card-header" />
              <ResetGridModal
                isOpen={resetGridModal}
                toggle={toggleResetGridModal}

              />

              <DataGrid
                id="gridContainer"
                dataSource={resourceData}
                className="esg-datagrid header-max-width"
                showBorders={false}
                showColumnLines={false}
                showRowLines={true}
                rowAlternationEnabled={true}
                columnAutoWidth={true}
              >
                <Paging defaultPageSize={10} />
                <Pager
                  visible={true}
                  showInfo={true}
                  showNavigationButtons={true}
                />
                <FilterRow visible={true} />

                <HeaderFilter visible={true} />
                <Column
                  dataField="name"
                  caption="Name"
                >
                  <HeaderFilter />
                </Column>
                <Column
                  dataField="abbreviation"
                  caption="Abbreviation"

                >
                  <HeaderFilter />
                </Column>
                <Column
                  dataField="assetType"
                  caption="Asset Type"
                >
                  <HeaderFilter />
                </Column>
                <Column
                  dataField="emissionName"
                  caption="Emission Scope"
                >
                  <HeaderFilter />
                </Column>


                <Column dataField="action_icon" width={"159px"} caption="Action" allowFiltering={false} allowSorting={false}
                  cellRender={(e: any) => {
                    return EditDeleteActionIcons(e.data.id)
                  }}>
                </Column>

              </DataGrid>

            </Card>
          </>
        )}
      </div>

      <div>
        <PopUpModal
          okButtonText="OK"
          cancelButtonText="Cancel"
          message={'Are you sure you want to  delete the selected Resource Type?'}
          modalHeading={'Confirm'}
          id=" "
          showModal={showModal}
          handleClickedOk={handleClickedOk}
          handleClickedCancel={handleClickedCancel}
        />
      </div>

    </>
  );
};

export default Settings;
