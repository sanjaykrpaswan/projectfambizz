import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, Toasts } from 'navex-react'
import './ResourceType.css'
import { useHistory } from 'react-router-dom';
import { useEffect, useState } from 'react';
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { Formik, Form, Field } from 'formik'
import {
    FormikSelect,
    FormikOption,
    FormikInput,
} from 'navex-react/lib/formik'
import Loader from '../../../common/loader/Loader';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const ResourceSchema = Yup.object().shape({
    resourceName: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
    assetType: Yup.string().required('field is required'),
    emissionScope: Yup.string().required('field is required'),
    abbreviation: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('field is required'),

})



const EditResourceType = (props: any) => {

    const [resourcetypeData, setResourcetypeData] = useState<any>();
    const [emissionData, setEmissionData] = useState<any[]>([])
    const [assetTypeData, setAssetTypeData] = useState<any[]>([])
    const [emissionDataKey, setemissionDataKey] = useState<any>();
    const [assetTypeKey, setassetTypeKey] = useState<any>();
    const [submitClicked,setSubmitClicked] =useState(false)
    const axiosInstance = useAxios();

    let temp: any;
    if(props.location.state === undefined){
        temp = window.localStorage.getItem("resourceTypeId");
    }
    const id = (temp !== undefined ? JSON.parse(temp) : props.location.state.resourceTypeId);


    /** API call to update the resource type */
    const handleEditResourceSubmit = async (value: any) => {
        setSubmitClicked(true);
        const payload = {
            id : id,
            name : value.resourceName,
            abbreviation : value.abbreviation,
            isDeleted : false,
            assetTypeId : value.assetType,
            emissionId :value.emissionScope,
            tenantId : Number(localStorage.getItem("tenantId"))    
        }
        const response = await axiosInstance.current?.put(apiservice.SettingsResourceType.updateResourceType(),payload);
        if (response?.status === RESPONSE_STATUS.success) {
            Toasts.success("Successfully updated Resource Type",{autoClose:3000});
            setSubmitClicked(false);
            cancelHandler();
        }
        else {
            Toasts.alert(response?.data.message,{autoClose:3000});
        }
    }

    /** API call to get the resource type details */
    const getResourceType = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsResourceType.viewResourceType(id));
        if (response?.status === RESPONSE_STATUS.success) {
            setResourcetypeData(response.data.data)
        }
        else {
            Toasts.alert(response?.data.message);
        }
    }

    /** API call to get the Emission and Asset type list */
    const getDropdownList = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsResourceType.getEmissionAndAssetTypelist());
        if (response?.status === RESPONSE_STATUS.success) {
            setEmissionData(response.data.data.emissionScope)
            setAssetTypeData(response.data.data.assetType)
        }
        else {
            Toasts.alert(response?.data.message);
        }
    }

    function getAssetTypeName(dvalue: any) {
        if (
            assetTypeData.length > 0 &&
            dvalue !== null &&
            dvalue !== undefined
        ) {
            const name = assetTypeData.filter(
                (rl: any) => rl.id === parseInt(dvalue)
            );
            return name[0].type;
        } else {
            return "Please select Asset Type";
        }
    }

    function onChangeAssetTypeValue(value: any): void {
        setassetTypeKey(Number(value));
    }

    function getEmissionScopeName(dvalue: any) {
        if (
            emissionData.length > 0 &&
            dvalue !== null &&
            dvalue !== undefined
        ) {
            const name = emissionData.filter(
                (rl: any) => rl.id === parseInt(dvalue)
            );
            return name[0].name;
        } else {
            return "Please select Emission Scope";
        }
    }

    function onChangeEmissionScopeValue(value: any): void {
        setemissionDataKey(Number(value));
    }



    useEffect((() => {
        getResourceType();
        getDropdownList();

    }), [])



    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/resourceType`);
    }

    return (

        <>
            {!(resourcetypeData && (submitClicked === false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Resource Type</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'>Edit Resource Type : {resourcetypeData.name}</h3>
                        <div style={{ marginTop: "60px" }}>
                            <Row style={{ textAlign: 'left' }}>
                                <Formik
                                    initialValues={{
                                        assetType: resourcetypeData.assetTypeId,
                                        emissionScope: resourcetypeData.emissionId,
                                        resourceName: resourcetypeData.name,
                                        abbreviation: resourcetypeData.abbreviation,
                                        submit: true,
                                    }}
                                    validationSchema={ResourceSchema}
                                    onSubmit={handleEditResourceSubmit}
                                >
                                    {({ values, errors, touched, isSubmitting, setFieldValue }) => (
                                        <Form style={{ width: '500px' }}>






                                            <Field
                                                name='assetType'
                                                label='Asset Type'
                                                required
                                                defaultTitle='Select Asset Type'
                                                component={FormikSelect}
                                                maxMenuHeight={'50px' && '186px'}
                                                vScrollAfter={10}
                                                value={
                                                    assetTypeKey || resourcetypeData.assetTypeId
                                                }
                                                title={getAssetTypeName(
                                                    assetTypeKey || resourcetypeData.assetTypeId
                                                )}
                                                onChange={(value: any) => {
                                                    onChangeAssetTypeValue(value);
                                                    setFieldValue("assetType", value);
                                                }}
                                                disabled ={true}
                                            >
                                                {assetTypeData.map((prov: any): any => {
                                                    return (
                                                        <FormikOption value={prov.id}>
                                                            {prov.type}
                                                        </FormikOption>
                                                    );
                                                })}



                                            </Field>

                                            <Field
                                                name='emissionScope'
                                                label='Emission Scope'
                                                required
                                                defaultTitle='Select Emission Type'
                                                component={FormikSelect}
                                                vScrollAfter={10}
                                                value={
                                                    emissionDataKey || resourcetypeData.emissionId
                                                }
                                                title={getEmissionScopeName(
                                                    emissionDataKey || resourcetypeData.emissionId
                                                )}
                                                onChange={(value: any) => {
                                                    onChangeEmissionScopeValue(value);
                                                    setFieldValue("emissionScope", value);
                                                }}
                                                disabled ={true}
                                            >
                                                {emissionData.map((prov: any): any => {
                                                    return (
                                                        <FormikOption value={prov.id}>
                                                            {prov.name}
                                                        </FormikOption>
                                                    );
                                                })}

                                            </Field>

                                            <Field
                                                name='resourceName'
                                                required
                                                label='Resource Name'
                                                component={FormikInput}

                                            />

                                            <Field
                                                name='abbreviation'
                                                label='Abbreviation'
                                                required
                                                component={FormikInput}

                                            />






                                            <Row style={{ marginTop: "16px" }}>
                                                <Col size={12} sm={12}>
                                                    <ButtonRow alignment="right">
                                                        <Button
                                                            purpose="default"
                                                            onClick={cancelHandler}

                                                        >
                                                            Cancel
                                                        </Button>
                                                        <Button id="save" type="submit" purpose="primary">
                                                            Save
                                                        </Button>
                                                    </ButtonRow>
                                                </Col>
                                            </Row>

                                        </Form>
                                    )}
                                </Formik>
                            </Row>
                        </div>
                    </div>
                </div>
            )
            }

        </>

    )
}

export default EditResourceType


