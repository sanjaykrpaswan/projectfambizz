import { Button, ButtonRow, FormikInput, FormikOption, FormikSelect, Toasts } from 'navex-react';
import { Accordion, Card } from 'navex-react/lib/cards';
import { useEffect, useState } from 'react';
import InlineEditDataGrid from '../../../common/InlineEditDataGrid';
import { useHistory } from 'react-router-dom';
import Loader from '../../../common/loader/Loader';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import './AssetCategory.css';
import apiservice from '../../../services/apiservice';
import { useAxios } from '../../../services/useAxios';
import { Field, Form, Formik } from 'formik';
const emissionScopeList = [
    { key: "Scope 1", value: "Scope 1" },
    { key: "Scope 2", value: "Scope 2" },
    { key: "Scope 3", value: "Scope 3" }

]


let TableColumns1 = [
    { name: "name", title: "Name" },
    { name: "field_type", title: "Field Type" },

];

const EditAssetcategory = (props: any) => {

    const [assetResourceList, setAssetResourceList] = useState<any>();
    const [categoryDetails, setcategoryDetails] = useState<any>();
    const [emissionScope, setemissionScope] = useState<any>();
    const [loaderEnable, setLoaderEnable] = useState<Boolean>(false);
    const axiosInstance = useAxios();

    /** API call to get the list of asset resource */
    const getAssetResourceList = async (id: any) => {
        
        const response = await axiosInstance.current?.get(apiservice.SettingsAssetCategory.getAssetResourceByCategoryId(assetCategoryId));
        if (response?.status === RESPONSE_STATUS.success) {
            setAssetResourceList(response.data.data)
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }
    }

    const handleEditResourceSubmit = async (value: any) => {
       
    }

    /** API call to get the SubCategoryDetails */
    const getSubCategoryDetails = async (id: any) => {
        setLoaderEnable(true);
        const response = await axiosInstance.current?.get(apiservice.SettingsAssetCategory.getSubCategoryDetailsById(id, assetCategoryId));
        if (response?.status === RESPONSE_STATUS.success) {
            setcategoryDetails(response.data.data)
            setLoaderEnable(false);
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
            setLoaderEnable(false);
        }
    }

    useEffect((() => {
        getAssetResourceList(assetCategoryId);

    }), [])


    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/assetCategory`);
    }

    const handleEmissionScope = (e: any) => {
        setemissionScope(e);
    }

    let temp: any;
    let tempName: any;
    if (props.location.state === undefined) {
        temp = window.localStorage.getItem("AssetCategoryId");
    }
    const assetCategoryId = (temp !== undefined ? JSON.parse(temp) : props.location.state.id);
    if (props.location.state === undefined) {
        temp = window.localStorage.getItem("AssetCategoryName");
    }
    const assetCategoryName = (temp !== undefined ? temp : props.location.state.name);


    return (

        <>
            {!(assetResourceList) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Asset Category</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'>Edit Asset Category : {assetCategoryName}</h3>
                        <div style={{ marginTop: "60px" }}>


                            <div >
                                <Accordion
                                    activeCardIndex={-1} >
                                    {assetResourceList.map((assetresource: any) => {
                                        var name = assetresource.name;
                                        var id = assetresource.id;
                                        return (
                                            <Card id={id} title={name} onClick={() => { getSubCategoryDetails(id) }} className="accordian_height">
                                                <div>
                                                <Button
                                                    style={{ float: "right" }}
                                                    purpose="primary"

                                                >
                                                    Add
                                                </Button>
                                                </div>
                                                {!(categoryDetails && (loaderEnable === false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                                                    <div style={{ marginTop: "40px" }}>
                                                        {Object.entries(categoryDetails).map(([key, values]) => {
                                                            return (

                                                                <Card id={key} title={key}  >
                                                                    <div >
                                                                        <Formik
                                                                            initialValues={{

                                                                                submit: true,

                                                                            }}
                                                                            onSubmit={handleEditResourceSubmit}

                                                                        >

                                                                            <Form style={{width :"400px" }} >


                                                                                <Field
                                                                                    name='key'
                                                                                    required
                                                                                    label='Name'
                                                                                    component={FormikInput}                           
                                                                                    value={key}


                                                                                />
                                                                                <Field
                                                                                    name='action'
                                                                                    label='Emission Scope'
                                                                                    component={FormikSelect}
                                                                                    maxMenuHeight={'40px' && '156px'}
                                                                                    required
                                                                                    title={emissionScope === undefined ? 'Scope 2' : emissionScope}
                                                                                    onChange={(e: any) => handleEmissionScope(e)}
                                                                                >
                                                                                    {emissionScopeList.map((prov: any) => (
                                                                                        <FormikOption value={prov.key}>{prov.value}</FormikOption>
                                                                                    ))}
                                                                                </Field>





                                                                            </Form>
                                                                        </Formik>
                                                                    </div>
                                                                    <div>
                                                                        <InlineEditDataGrid
                                                                            columns={TableColumns1}
                                                                            gridData={values}
                                                                            gridTitle={"Measures"}
                                                                            isFilterRow
                                                                            isHeaderBar
                                                                            isHeaderFilter
                                                                            onSave
                                                                            allowUpdate
                                                                            showOnlyAdd
                                                                            allowAdd
                                                                            allowDelete
                                                                        />
                                                                    </div>
                                                                </Card>
                                                            )
                                                        })}
                                                    </div>
                                                )}
                                            </Card>
                                        )
                                    })}
                                </Accordion>
                                <div style={{ marginTop: "16px" }}>
                                    <ButtonRow alignment="right">
                                        <Button
                                            purpose="default"
                                            onClick={cancelHandler}

                                        >
                                            Cancel
                                        </Button>

                                    </ButtonRow>
                                </div>


                            </div>


                        </div>
                    </div>
                </div>

            )}
        </>

    )
}

export default EditAssetcategory


