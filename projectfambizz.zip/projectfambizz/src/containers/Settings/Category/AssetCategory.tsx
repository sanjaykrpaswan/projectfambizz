import { FC, useEffect, useState } from "react";
import Card from "reactstrap/lib/Card";
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { ActionIcon, Button, dxReactGrid, Toasts } from "navex-react";
import 'devextreme/dist/css/dx.light.css';
import { useHistory } from 'react-router-dom';
import { faEye, faPencilAlt, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import "../../../styles/styles.css";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import Loader from "../../../common/loader/Loader";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";



const { ResetGridModal, TableHeaderNavbar } = dxReactGrid;



export const Category: FC<any> = (props: any) => {

  const history = useHistory();
  const axiosInstance = useAxios();


  const [resetGridModal, setResetGridModal] = useState(false);
  const [fetchingAssetList, setFetchingAssetList] = useState(false);
    const [assetList, setAssetList] = useState<any>([]);
  let tenantId = localStorage.getItem("tenantId");


   /** API call to get the Asset Detail list */
   const getAssetCategoryDetails = async () => {
    setFetchingAssetList(true);
    const response = await axiosInstance.current?.get(apiservice.SettingsAssetCategory.getAssetDetails());
    if (response?.status === RESPONSE_STATUS.success) {
        setAssetList(response.data.data)
        setFetchingAssetList(false)
    } else {
        Toasts.alert(response?.data.message)
    }
}
 
const editAssetCategoryHandler = (id: any , name : any) => {
  window.localStorage.setItem("AssetCategoryId", id);
  window.localStorage.setItem("AssetCategoryName", name);
  history.push(`/esg/${localStorage.getItem("tanentName")}/settings/assetCategory/editAssetCategory`);
}


  const toggleResetGridModal = () => {
    setResetGridModal(!resetGridModal);
  };

  useEffect(() => {
    getAssetCategoryDetails();
}, [])




  /** Functional component to render action icons in each row of the grid */

  const EditDeleteActionIcons = (id: any , name : any) => {
    return (
      <>
        <div>

          <ActionIcon
            id="view"
            icon={faEye}
            toolTip="View"
            disabled={false}
            data-toggle="modal"
        
          >

          </ActionIcon>

          <ActionIcon
            id="edit"
            icon={faPencilAlt}
            toolTip="Edit"
            disabled={false}
            data-toggle="modal"
            onClick={() => { editAssetCategoryHandler(id , name) }}
           
          />

          <ActionIcon
            id="deleteGroup"
            icon={faTrashAlt}
            toolTip="Delete"
            disabled={false}
            data-toggle="modal"
            

          />
        </div>
      </>
    );

  };

  return (
    <>

      <h1 className="esg-page-heading">Asset Category</h1>
      <hr className="line" />
      <div className="all-page-container ">

      {fetchingAssetList ? <Loader style={{ left: "45%", right: "50%", marginTop: "10%" }} /> : (
          <>
            <Button
              style={{ float: "right", marginTop: "15px" }}
              purpose="primary"
            >
              Add 
            </Button>



            <Card className="dx-nsg-react-grid survey-table-root dataGrid-card-noheader" style={{ marginTop: "55px" }}>
              <div className="card-header" />
              <ResetGridModal
                isOpen={resetGridModal}
                toggle={toggleResetGridModal}

              />

              <DataGrid
                id="gridContainer"
                dataSource={assetList}
                className="esg-datagrid header-max-width"
                showBorders={false}
                showColumnLines={false}
                showRowLines={true}
                rowAlternationEnabled={true}
                columnAutoWidth={true}
              >
                <Paging defaultPageSize={10} />
                <Pager
                  visible={true}
                  showInfo={true}
                  showNavigationButtons={true}
                />
                <FilterRow visible={true} />

                <HeaderFilter visible={true} />
                <Column
                  dataField="name"
                  caption="Name"
                >
                  <HeaderFilter />
                </Column>
                <Column
                  dataField="count"
                  caption="Subtypes"
                  alignment={"left"}
                  width={"265px"}

                >
                  <HeaderFilter />
                </Column>

                <Column dataField="action_icon" width={"165px"} caption="Action" allowFiltering={false} allowSorting={false}
                  cellRender={(e: any) => {
                    return EditDeleteActionIcons(e.data.id , e.data.name)
                  }}>
                </Column>

              </DataGrid>

            </Card>
          </>
      )}

      </div>

    

    </>
  );
};

export default Category;
