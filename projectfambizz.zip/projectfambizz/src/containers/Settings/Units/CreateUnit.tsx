import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, FormikInput, FormikSelect, FormikOption, Toasts } from 'navex-react'
import './units.css'
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { useHistory } from 'react-router-dom';
import { Formik, Form, Field } from 'formik'
import {useState } from 'react';
import Loader from '../../../common/loader/Loader';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const UnitAddSchema = Yup.object().shape({
    extendedName: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
    abbreviation: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('field is required'),

})

const CreateUnit = (props: any) => {

    const [unitData, setUnitData] = useState<any[]>([])
    const [submitClicked,setSubmitClicked] =useState(false)
    const axiosInstance = useAxios();

    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/units`);
    }

    const handleUnitSubmit = async (value: any, actions : any) => {
        setSubmitClicked(true);
        const payload = {
            name : value.unitGroupName,
            defaultName : value.unitGroupName,
            isDeleted : false,
            isDefault : false,
            tenantId : Number(localStorage.getItem("tenantId")) 
          }
        const response = await axiosInstance.current?.post(apiservice.SettingsUnits.createUnit(),payload);
        if (response?.status === 200) {
            setUnitData(response.data.data)
            Toasts.success(response.data.message, {autoClose: 3000});
            cancelHandler();
        }
        else if (response?.status === 406) {
            setSubmitClicked(false);
            Toasts.alert(response.data.message, {autoClose:3000});
            actions.resetForm();
        }
        else {
            Toasts.alert(response?.data.message, {autoClose:3000});
        }

    }

    return (

        <>
            {!(unitData && (submitClicked === false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Unit</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'> Add Unit: </h3>
                        <div className="unit-form">
                            <Row style={{ textAlign: 'left' }}>
                                <Formik
                                    initialValues={{
                                        extendedName: '',
                                        abbreviation: '',
                                        submit: true,
                                    }}
                                    validationSchema={UnitAddSchema}
                                    onSubmit={handleUnitSubmit}
                                >
                                    <Form style={{ width: '500px' }}>
                                        <Field
                                            name='extendedName'
                                            required
                                            label='Unit Name'
                                            component={FormikInput}

                                        />
                                        <Field
                                            name='abbreviation'
                                            label='Abbreviation'
                                            component={FormikInput}
                                        />
                                        <Row style={{ marginTop: "16px" }}>
                                            <Col size={12} sm={12}>
                                                <ButtonRow alignment="right">
                                                    <Button
                                                        purpose="default"
                                                        onClick={cancelHandler}
                                                    >
                                                        Cancel
                                                    </Button>
                                                    <Button id="save" type="submit" purpose="primary" >
                                                        Save
                                                    </Button>
                                                </ButtonRow>
                                            </Col>
                                        </Row>

                                    </Form>
                                </Formik>

                            </Row>

                        </div>
                    </div>
                </div>

            )}
        </>

    )
}

export default CreateUnit

