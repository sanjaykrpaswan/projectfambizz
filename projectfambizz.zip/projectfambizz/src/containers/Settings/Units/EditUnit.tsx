import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, Toasts, Card } from 'navex-react'
import './units.css'
import { useHistory } from 'react-router-dom';
import { useEffect, useState } from 'react';
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { Formik, Form, Field } from 'formik'
import {
    FormikInput
} from 'navex-react/lib/formik'
import Loader from '../../../common/loader/Loader';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const UnitSchema = Yup.object().shape({
    extendedName: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
    abbreviation: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('field is required'),

})


const EditUnit = (props: any) => {

    const [unitData, setUnitData] = useState<any>();
    const axiosInstance = useAxios();

    let temp: any;
    if(props.location.state === undefined){
        temp = window.localStorage.getItem("unitId");
    }
    const id = (temp !== undefined ? JSON.parse(temp) : props.location.state.unitId);

    const getUnit = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsUnits.getUnitById(id));
        if (response?.status === 200) {
            setUnitData(response.data.data)
        }
        else {
            Toasts.alert(response?.data.message);
        }
    }

    const handleEditUnitSubmit = async (value: any) => {
        const payload = {
            id : value.id,
            abbreviation : value.abbreviation,
            extendedName : value.name,
            isDeleted : false,
            unitGroupsId: Number(value.unitGroupsId),
            tenantId : Number(localStorage.getItem("tenantId"))
          }
        const response = await axiosInstance.current?.put(apiservice.SettingsUnits.updateUnitById(),payload);
        if (response?.status === 200) {
            Toasts.success("Successfully Updated Unit");
            cancelHandler();
        }
        else {
            Toasts.alert(response?.data.message);
        }

    }

    useEffect((() => {
        getUnit();
    }), [])

    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/units`);
    }

    return (
        <>
            {!(unitData) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Unit</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                    <h3 className='esg-page-sub-heading'>Edit Unit : {unitData.extendedName}</h3>
                        <div className="unit-form">
                            <Row style={{ textAlign: 'left' }}>
                                <Formik
                                    initialValues={{
                                        extendedName: unitData.extendedName,
                                        abbreviation: unitData.abbreviation,
                                        submit: true,
                                    }}
                                    validationSchema={UnitSchema}
                                    onSubmit={handleEditUnitSubmit}
                                >
                                    <Form style={{ width: '500px' }}>
                                        <Field
                                            name='extendedName'
                                            required
                                            label='Unit Name'
                                            component={FormikInput}
                                        />
                                        <Field
                                            name='abbreviation'
                                            label='Abbreviation'
                                            component={FormikInput}
                                        />
                                        <Row style={{ marginTop: "16px" }}>
                                            <Col size={12} sm={12}>
                                                <ButtonRow alignment="right">
                                                    <Button
                                                        purpose="default"
                                                        onClick={cancelHandler}
                                                    >
                                                        Cancel
                                                    </Button>
                                                    <Button id="save" type="submit" purpose="primary" >
                                                        Save
                                                    </Button>
                                                </ButtonRow>
                                            </Col>
                                        </Row>

                                    </Form>
                                </Formik>

                            </Row>

                        </div>
                    </div>
                </div>
            )}

        </>

    )
}

export default EditUnit

