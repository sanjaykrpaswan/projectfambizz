import { Card } from "reactstrap";
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { ActionIcon, Button, dxReactGrid, Toasts } from "navex-react";
import 'devextreme/dist/css/dx.light.css';
import { useEffect, useState } from "react";
import { faEye, faPencilAlt, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import './units.css'
import '../../../styles/styles.css'
import Loader from "../../../common/loader/Loader";
import { useHistory } from 'react-router-dom';
import LiveExampleContent from "../../../common/PopUp/popModal";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";
const { ResetGridModal ,TableHeaderNavbar} = dxReactGrid;




const Units = () => {
    const history = useHistory();
    const [resetGridModal, setResetGridModal] = useState(false);
    const [fetchingUnitList, setFetchingUnitList] = useState(false);
    const [unitsList, setUnitsList] = useState<any>([]);
    const [unitId, setUnitId] = useState<any>();
    const [showModal, setShowModal] = useState(false);
    const axiosInstance = useAxios();


    const open = (id : any) => {
    setShowModal(true);
    setUnitId(id);
  }

  const close = () => setShowModal(false);  

    const toggleResetGridModal = () => {
        setResetGridModal(!resetGridModal);
    };

    /** API call to get the units list */
    const getUnitsList = async () => {
        setFetchingUnitList(true);
        const response = await axiosInstance.current?.get(apiservice.SettingsUnits.getUnitsList());
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitsList(response.data.data)
            setFetchingUnitList(false)
        } else {
            Toasts.alert(response?.data.message)
        }
    }

    

    const unitsViewHandler = (id: any) => {
        window.localStorage.setItem("unitId", id);
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/units/viewUnit`, { data: { unitId: id } })
    }

    const editUnitHandler =(id : any) =>{
        window.localStorage.setItem("unitId", id);
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/units/editUnit`,{unitId : id });
      }
      
      const addHandler  = () => {
        history.push(
          `/esg/${localStorage.getItem("tanentName")}/settings/units/addUnit`
        );
      };
      
      const handleClickedCancel = () => {
        close();
      }
      
      const handleClickedOk = async() =>{
        close();
        const response = await axiosInstance.current?.delete(apiservice.SettingsUnits.deleteUnitById(unitId));
        if(response?.status === 200){
      
          Toasts.success("Successfully deleted Unit" ,{autoClose:3000}); 
          getUnitsList();
      
        }else {
          Toasts.alert("Failed to delete the Unit",{autoClose:3000});
        }
      }

    /** Functional component to render action icons in each row of the grid */
    const EditDeleteActionIcons = (id: any) => {
        return (
            <>
                <div>
                    <ActionIcon
                        id="view"
                        icon={faEye}
                        toolTip="View"
                        disabled={false}
                        data-toggle="modal"
                        onClick={()=>unitsViewHandler(id)}
                    />

                    <ActionIcon
                        id="edit"
                        icon={faPencilAlt}
                        toolTip="Edit"
                        disabled={false}
                        data-toggle="modal"
                        onClick={()=>editUnitHandler(id)}
                        
                    />

                    <ActionIcon
                        id="deleteGroup"
                        icon={faTrashAlt}
                        toolTip="Delete"
                        disabled={false}
                        data-toggle="modal"
                        onClick={() => open(id)}
                    />
                </div>
            </>
        );
    };

    useEffect(() => {
        getUnitsList();
    }, [])

    return (
        <>
            <h1 className="esg-page-heading">Units</h1>
            <hr className="line" />
            <div className="all-page-container ">
                {fetchingUnitList ? <Loader style={{ left: "45%", right: "50%", marginTop: "10%" }} /> : (
                    <><Button purpose="primary" className="newUnitButton" onClick={addHandler} disabled>Add </Button>
                        <Card style={{marginTop : "55px"}} className="dx-nsg-react-grid units-table-root dataGrid-card-noheader">
                       
                            <div className="card-header" />
                            <ResetGridModal
                                isOpen={resetGridModal}
                                toggle={toggleResetGridModal} />

                            <DataGrid
                                id="gridContainer"
                                dataSource={unitsList}
                                className="esg-datagrid header-max-width"
                                showBorders={false}
                                showColumnLines={false}
                                showRowLines={true}
                                rowAlternationEnabled={true}
                                columnAutoWidth={true}
                            >
                                <Paging defaultPageSize={10} />
                                <Pager
                                    visible={true}
                                    showInfo={true}
                                    showNavigationButtons={true} />
                                <FilterRow visible={true} />

                                <HeaderFilter visible={true} />
                                <Column
                                    dataField="extendedName"
                                    caption="Name">
                                <HeaderFilter />
                                </Column>
                                <Column
                                    dataField="abbreviation"
                                    caption="Abbreviation">
                                <HeaderFilter />
                                </Column>
                                <Column 
                                    dataField="action_icon"
                                    width={"159px"}
                                    caption="Action"
                                    allowFiltering={false}
                                    allowSorting={false}
                                    cellRender={(e: any) => {
                                        return EditDeleteActionIcons(e.data.id);
                                    }}>
                                </Column>
                            </DataGrid>
                        </Card>
                    </>
                )}
            </div>
            <div>
        <LiveExampleContent
          okButtonText="OK"
          cancelButtonText="Cancel"
          message={'Are you sure you want to  delete the selected Unit?'}
          modalHeading={'Confirm'}
          id=" "
          showModal={showModal}
          handleClickedOk={handleClickedOk}
          handleClickedCancel={handleClickedCancel}
        />
      </div>
        </>
    )
}

export default Units;
