import { Button, ButtonRow, Toasts } from 'navex-react';
import { Col, Row } from 'reactstrap';
import '../../../styles/styles.css'
import { useHistory } from 'react-router-dom';
import './units.css'
import { useEffect, useState } from 'react';
import Loader from '../../../common/loader/Loader';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const ViewUnits = (props: any) => {

    const history = useHistory();
    const axiosInstance = useAxios();

    const [unitData, setUnitData] = useState<any>()

    let temp: any;
    props.location.state === undefined ? temp = window.localStorage.getItem("unitId") : temp = props.location.state.data.unitId;
    const unitId = JSON.parse(temp);

    const getUnitData = async (unitId: any) => {
        const res = await axiosInstance.current?.get(apiservice.SettingsUnits.getUnitById(unitId));
        if (res?.status === 200) {
            setUnitData(res.data.data)
        } else {
            Toasts.alert(res?.data.message, { autoClose: 3000 })
        }
    }
    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/units`);
    }

    const editUnitHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/units/editUnit`, { unitId: unitId });
    }

    useEffect(() => {
        getUnitData(unitId)
    }, [])
    return (
        <>
            {!(unitData) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">View Units</h1>
                    <hr className="line" />
                    <div className="all-page-container ">

                        <div style={{ marginTop: '15px' }}>

                            <Row className='view-unit-info'>
                                <Col className="sd-label" size={12} sm={2}>Unit Name :</Col>
                                <Col style={{ borderTop: '0px' }}>{unitData.abbreviation}</Col>
                            </Row>

                            <Row className='view-unit-info'>
                                <Col className="sd-label" size={12} sm={2}>Extended Name:</Col>
                                <Col style={{ borderTop: '0px' }}>{unitData.extendedName}</Col>
                            </Row>


                        </div>
                        <div>
                            <ButtonRow alignment='right'>
                                <Button purpose='default' onClick={cancelHandler}>Cancel</Button>
                                <Button purpose='primary' onClick={editUnitHandler}>Edit</Button>
                            </ButtonRow>
                        </div>



                    </div>
                </div>
            )}
        </>
    )
}
export default ViewUnits;