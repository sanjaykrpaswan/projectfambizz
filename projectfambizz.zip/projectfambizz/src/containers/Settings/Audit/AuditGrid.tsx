import { useEffect, useState } from 'react'
import { Accordion, Card } from 'navex-react/lib/cards'
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { getFormattedDate, getFormattedDateTime } from '../../../common/StringUtil';
import '../Audit/Audit.css'
import { Field, Form, Formik } from 'formik';
import { Col, Row } from 'reactstrap';
import { ActionIcon, Button, ButtonRow, dxReactGrid, FormikDatePicker, FormikOption, FormikSelect, Toasts } from 'navex-react';
import * as Yup from 'yup';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import { faDownload } from '@fortawesome/free-solid-svg-icons';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const { TableHeaderNavbar } =
  dxReactGrid;

const validateSchema = Yup.object().shape({
  fromDate: Yup.string().required('field is required'),
  toDate: Yup.string().required('field is required'),
})

export const AuditGrid = (props: any) => {
  const gridData = props?.props;
  const [startDate, setStartDate] = useState<any>();
  const [endDate, setEndDate] = useState<any>();
  const [fieldName, setFieldName] = useState<any>();
  const [userName, setUserName] = useState<any>();
  const [userList, setUserList] = useState<any>();
  const [fieldList, setFieldList] = useState<any>();
  const [operation, setOperation] = useState<any>();
  const [filteredData, setFilteredData] = useState<any>();
  const [isFilterApplied, setIsFilterAppiled] = useState(false);
  const operations = [
    { key: "All", value: "All" },
    { key: "Add", value: "Add" },
    { key: "Update", value: "Update" },
    { key: "Delete", value: "Delete" }
  ]
  const axiosInstance = useAxios();

  // API call to fetch user list
  const getUserList = async () => {
    let response: any;
    if (props?.location === `/esg/${localStorage.getItem("tanentName")}/settings/resourceType/viewResourceType`) {
      response = await axiosInstance.current?.get(apiservice.Audit.auditUserList("asset_resource"));
    } else if (props?.location === `/esg/${localStorage.getItem("tanentName")}/settings/currency/viewCurrency`) {
      response = await axiosInstance.current?.get(apiservice.Audit.auditUserList("currency"));
    } else if (props?.location === `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/viewUnitGroup`) {
      response = await axiosInstance.current?.get(apiservice.Audit.auditUserList("unit_groups"));
    }
    if (response?.status === RESPONSE_STATUS.success) {
      setUserList(response.data.data);
    } else {
      Toasts.alert("No record found for users", { autoClose: 3000 });
    }
  }

  // API call to fetch fields list 
  const getFieldsList = async () => {
    let response: any;
    if (props?.location === `/esg/${localStorage.getItem("tanentName")}/settings/resourceType/viewResourceType`) {
      response = await axiosInstance.current?.get(apiservice.Audit.auditFieldsList("asset_resource"));
    } else if (props?.location === `/esg/${localStorage.getItem("tanentName")}/settings/currency/viewCurrency`) {
      response = await axiosInstance.current?.get(apiservice.Audit.auditFieldsList("currency"));
    } else if (props?.location === `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/viewUnitGroup`) {
      response = await axiosInstance.current?.get(apiservice.Audit.auditFieldsList("unit_groups"));
    }
    if (response?.status === RESPONSE_STATUS.success) {
      setFieldList(response.data.data);
    } else {
      Toasts.alert("No record found for fields", { autoClose: 3000 });
    }
  }

  const customTextOldVlaue = (values: any) => {
    if (values.oldValue !== null) {
      const oldValueList = Object.entries(values.oldValue).map(([key, value]) => {
        return (
          <><b>{key}: </b>{value}<br /></>
        );
      })
      return oldValueList;

    } else {
      return "";
    }
  }

  const customTextNewVlaue = (values: any) => {
    if (values?.newValue !== null) {
      const newValueList = Object.entries(values.newValue).map(([key, value]) => {
        return (
          <><b>{key}: </b>{value}<br /></>
        );
      })
      return newValueList;
    } else {
      return "";
    }
  }

  const handleStartDate = (e: any) => {
    setStartDate(getFormattedDate(e));
  }

  const handleEndDate = (e: any) => {
    setEndDate(getFormattedDate(e !== '' || e !== undefined ? e : new Date()));
  }

  const handleFieldName = (e: any) => {
    setFieldName(e)
  }

  const handleUserName = (e: any) => {
    setUserName(e)
  }

  const handleOperations = (e: any) => {
    setOperation(e);
  }

  function filterDataByDate(startDate: any, endDate: any) {
    let filteredData = gridData.filter((date: any) => getFormattedDate(date.updatedOn) >= startDate && getFormattedDate(date.updatedOn) <= endDate);
    return filteredData;
  }

  function filterDataByField(fieldName: any) {
    return gridData.filter((item: any) => item.tempNewValue.includes(fieldName))
  }

  function filterDataByUser(userName: any) {
    return gridData.filter((item: any) => item.updatedBy === userName);
  }

  function filterDataByOperation(operation: any) {
    if (operation === "All") {
      return gridData;
    } else {
      return gridData.filter((item: any) => item.operation === operation);
    }
  }

  const applyFilter = (startDate: any, endDate: any, operation: any, userName: any, fieldName: any) => {
    let filterByDateOperation: any = [];
    let filterByDateUserName: any = [];
    let filterByOperationUserName: any = [];
    let filterData: any = [];
    if (startDate !== undefined &&
      endDate !== undefined &&
      operation === undefined &&
      userName === undefined &&
      fieldName === undefined) {
      setFilteredData(filterDataByDate(startDate, endDate));
    }
    else if (
      startDate === undefined &&
      endDate === undefined &&
      operation === undefined &&
      userName === undefined &&
      fieldName !== undefined) {
      setFilteredData(filterDataByField(fieldName));
    }
    else if (startDate === undefined &&
      endDate === undefined &&
      operation === undefined &&
      userName !== undefined &&
      fieldName === undefined) {
      setFilteredData(filterDataByUser(userName));
    }
    else if (startDate === undefined &&
      endDate === undefined &&
      operation !== undefined &&
      userName === undefined &&
      fieldName === undefined) {
      setFilteredData(filterDataByOperation(operation));
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation === undefined &&
      userName === undefined &&
      fieldName !== undefined) {
      let filterByDateFieldName = filterDataByDate(startDate, endDate);
      setFilteredData(filterByDateFieldName.filter((item: any) => item.tempNewValue.includes(fieldName)));
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation !== undefined &&
      userName === undefined &&
      fieldName === undefined) {
      filterByDateOperation = filterDataByDate(startDate, endDate);
      setFilteredData(filterByDateOperation.filter((item: any) => item.operation === operation));
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation === undefined &&
      userName !== undefined &&
      fieldName === undefined) {
      filterByDateUserName = filterDataByDate(startDate, endDate);
      setFilteredData(filterByDateUserName.filter((item: any) => item.updatedBy === userName));
    }
    else if (startDate === undefined &&
      endDate === undefined &&
      operation !== undefined &&
      userName !== undefined &&
      fieldName === undefined) {
      filterByOperationUserName = filterDataByUser(userName);
      setFilteredData(filterByOperationUserName.filter((item: any) => item.operation === operation))
    }
    else if (startDate === undefined &&
      endDate === undefined &&
      operation === undefined &&
      userName !== undefined &&
      fieldName !== undefined) {
      let filterByFieldUserName = filterDataByUser(userName);
      setFilteredData(filterByFieldUserName.filter((item: any) => item.tempNewValue.includes(fieldName)))
    }
    else if (startDate === undefined &&
      endDate === undefined &&
      operation !== undefined &&
      userName === undefined &&
      fieldName !== undefined) {
      let fiterByFieldOperation = filterDataByOperation(operation);
      setFilteredData(fiterByFieldOperation.filter((item: any) => item.tempNewValue.includes(fieldName)))
    } else if (startDate === undefined &&
      endDate === undefined &&
      operation !== undefined &&
      userName !== undefined &&
      fieldName !== undefined) {
      let filterByOperationUser = (filterDataByOperation(operation)).filter((item: any) => item.updatedBy === userName);
      setFilteredData(filterByOperationUser.filter((item: any) => item.tempNewValue.includes(fieldName)))
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation !== undefined &&
      userName !== undefined &&
      fieldName === undefined) {
      filterData = (filterDataByOperation(operation)).filter((item: any) => item.updatedBy === userName);
      setFilteredData(filterData.filter((date: any) => getFormattedDate(date.updatedOn) >= startDate && getFormattedDate(date.updatedOn) <= endDate));
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation !== undefined &&
      userName === undefined &&
      fieldName !== undefined) {
      filterData = (filterDataByOperation(operation)).filter((item: any) => item.tempNewValue.includes(fieldName));
      setFilteredData(filterData.filter((date: any) => getFormattedDate(date.updatedOn) >= startDate && getFormattedDate(date.updatedOn) <= endDate));
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation === undefined &&
      userName !== undefined &&
      fieldName !== undefined) {
      filterData = (filterDataByUser(userName)).filter((item: any) => item.tempNewValue.includes(fieldName));
      setFilteredData(filterData.filter((date: any) => getFormattedDate(date.updatedOn) >= startDate && getFormattedDate(date.updatedOn) <= endDate));
    }
    else if (startDate !== undefined &&
      endDate !== undefined &&
      operation !== undefined &&
      userName !== undefined &&
      fieldName !== undefined) {
      filterData = (filterDataByUser(userName)).filter((item: any) => item.tempNewValue.includes(fieldName)).filter((item: any) => item.operation === operation);
      setFilteredData(filterData.filter((date: any) => getFormattedDate(date.updatedOn) >= startDate && getFormattedDate(date.updatedOn) <= endDate));
    }
  }

  const handleSubmit = () => {
    setIsFilterAppiled(true);
    applyFilter(startDate, endDate, operation, userName, fieldName);
  }

  function clearButtonHandler() {
    setStartDate(undefined);
    setEndDate(undefined);
    setFieldName(undefined)
    setUserName(undefined);
    setOperation(undefined);
    setIsFilterAppiled(false);
  }

  const downloadFile = ({ data, fileName, fileType }: any) => {
    const blob = new Blob([data], { type: fileType })

    const a = document.createElement('a')
    a.download = fileName
    a.href = window.URL.createObjectURL(blob)
    const clickEvt = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
    })
    a.dispatchEvent(clickEvt)
    a.remove()
  }

  //function to export the grid data
  const exportToCsv = (e: any) => {
    e.preventDefault()

    // Headers for each column
    let headers = ['Date,Old Value,NewValue,Operation,Changed By,Status'];

    // Convert users data to a csv
    let auditCsv = (isFilterApplied ? filteredData : gridData).reduce((audit: any, data: any) => {
      const { updatedOn, tempOldValue, tempNewValue, operation, updatedBy, status } = data;
      audit.push([updatedOn, tempOldValue.replace(/[{}""null]/g, '').replaceAll(',', ';'), tempNewValue.replace(/[{}""null]/g, '').replaceAll(',', ';'), operation, updatedBy, status].join(','))
      return audit
    }, [])

    downloadFile({
      data: [...headers, ...auditCsv].join('\n'),
      fileName: 'Audit.csv',
      fileType: 'text/csv',
    })
  }

  let title = (<div className='parenttitle'>
    <div className='auidt-export'>
      <ActionIcon
        id="download"
        icon={faDownload}
        toolTip="Export"
        disabled={false}
        onClick={exportToCsv}
      />
    </div>
  </div>)

  useEffect(() => {
    getUserList();
    getFieldsList();
  }, [])

  return (
    <>
      <Accordion
        activeCardIndex={-1}>
        <Card id="Audit" title="History">
          {userList && fieldList && <div>
            <Formik
              initialValues={{
                submit: true,
              }}
              onSubmit={handleSubmit}
              validationSchema={validateSchema}
            >
              <Form style={{ width: '100%', marginTop: '10px' }}>
                <Row>
                  <Col >
                    <Field
                      name="fromDate"
                      label="From"
                      component={FormikDatePicker}
                      className="from-date-css"
                      value={startDate}
                      onChange={(e: any) => handleStartDate(e)}
                    />
                  </Col>
                  <Col >
                    <Field
                      name="toDate"
                      label="To"
                      component={FormikDatePicker}
                      className="to-date-css"
                      value={endDate}
                      onChange={(e: any) => handleEndDate(e)}
                    />
                  </Col>
                  <Col>
                    <Field
                      name='displayName'
                      label='Field'
                      component={FormikSelect}
                      maxMenuHeight={'30px' && '106px'}
                      title={fieldName === undefined ? 'Select a Field' : fieldName}
                      onChange={(e: any) => handleFieldName(e)}
                    >
                      {fieldList.map((prov: any) => (
                        <FormikOption value={prov.displayName}>{prov.displayName}</FormikOption>
                      ))}
                    </Field>
                  </Col>
                  <Col>
                    <Field
                      name='name'
                      label='User'
                      component={FormikSelect}
                      maxMenuHeight={'30px' && '106px'}
                      title={userName === undefined ? 'Select a User' : userName}
                      onChange={(e: any) => handleUserName(e)}
                    >
                      {userList.map((prov: any) => (
                        <FormikOption value={prov.name}>{prov.name}</FormikOption>
                      ))}
                    </Field>
                  </Col>
                  <Col>
                    <Field
                      name='action'
                      label='Operation'
                      component={FormikSelect}
                      maxMenuHeight={'30px' && '106px'}
                      title={operation === undefined ? 'Select an Operation' : operation}
                      onChange={(e: any) => handleOperations(e)}
                    >
                      {operations.map((prov: any) => (
                        <FormikOption value={prov.key}>{prov.value}</FormikOption>
                      ))}
                    </Field>
                  </Col>
                  <Col className="apply-button">
                    <ButtonRow alignment="left">
                      <>
                        <Button type='submit' purpose='default' onClick={handleSubmit}>
                          Apply
                        </Button>
                        <Button type='reset' purpose='default' onClick={clearButtonHandler}>
                          Clear
                        </Button>
                      </>
                    </ButtonRow>
                  </Col>
                </Row>
              </Form>
            </Formik>
          </div>}
          <div className='audit-grid'>
            <TableHeaderNavbar
              tableTitle={title}
            />
            <DataGrid
              id="gridContainer"
              dataSource={isFilterApplied ? filteredData : gridData}
              className="esg-datagrid header-max-width audit-datagrid"
              showBorders={false}
              showColumnLines={false}
              showRowLines={true}
              rowAlternationEnabled={true}
              columnAutoWidth={true}
            >
              <Paging defaultPageSize={10} />
              <Pager
                visible={true}
                showInfo={true}
                showNavigationButtons={true}
              />
              <FilterRow visible={true} />
              <HeaderFilter visible={true} />
              <Column
                dataField="updatedOn"
                caption="Date"
                sortOrder={"desc"}
                cssClass="audit-column"
                cellRender={(e: any) => { return getFormattedDateTime(e.data.updatedOn) }}
              />

              <Column
                dataField="tempOldValue"
                caption="Old Value"
                cellRender={(e: any) => { return customTextOldVlaue(e.data) }}
              >
                <HeaderFilter />
              </Column>

              <Column
                dataField="tempNewValue"
                caption="New Value"
                cellRender={(e: any) => { return customTextNewVlaue(e.data) }}
              >
                <HeaderFilter />
              </Column>

              <Column
                dataField="operation"
                caption="Operation"
              >
                <HeaderFilter />
              </Column>

              <Column
                dataField="updatedBy"
                caption="Changed By"
              >
                <HeaderFilter />
              </Column>

              <Column
                dataField="status"
                caption="Status"
              >
                <HeaderFilter />
              </Column>

            </DataGrid>
          </div>
        </Card>
      </Accordion>
    </>
  )
}
