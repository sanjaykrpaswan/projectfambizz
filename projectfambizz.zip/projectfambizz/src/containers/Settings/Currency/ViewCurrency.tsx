import { Button, ButtonRow, Toasts } from 'navex-react';
import { Col, Row } from 'reactstrap';
import '../../../styles/styles.css'
import { useHistory } from 'react-router-dom';
import './Currency.css'
import { useEffect, useState } from 'react';
import Loader from '../../../common/loader/Loader';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import {AuditGrid} from '../Audit/AuditGrid';
import CurrencyCoversionGrid from './CurrencyConversionGrid';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const ViewCurrency = (props: any) => {

    const history = useHistory();
    const axiosInstance = useAxios();

    const [currencyData, setCurrencyData] = useState<any>();
    const [auditDetails, setAuditDetails] = useState<any>();
    const [currencyConversionDetails, setCurrencyConversionDetails] = useState<any>();
    let tenantId = localStorage.getItem("tenantId");

    let temp: any;
    props.location.state === undefined ? temp = window.localStorage.getItem("currencyId") : temp = props.location.state.data.currencyId;
    const currencyId = JSON.parse(temp);

    const getCurrencyData = async (currencyId: any) => {
        const res = await axiosInstance.current?.get(apiservice.SettingsCurrency.getCurrecyById(currencyId));
        if (res?.status === 200) {
            setCurrencyData(res.data.data)
        } else {
            Toasts.alert(res?.data.message, { autoClose: 3000 })
        }
    }
    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/currency`);
    }

    const editCurrencyHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/currency/editCurrency`, { currencyId: currencyId });
    }

     /** API call to get the audit details of resource type */
     const getAuditDetails = async () => {
        const response = await axiosInstance.current?.get(apiservice.Audit.auditDetails("currency",currencyId,tenantId));
        if (response?.status === RESPONSE_STATUS.success) {
            response?.data?.data?.map((item:any)=>{
                item.tempOldValue = JSON.stringify(item.oldValue)
                item.tempNewValue = JSON.stringify(item.newValue)
              })
            setAuditDetails(response.data.data)

        }
        else {
            Toasts.alert(response?.data.message, {autoClose: 3000});
        }
    }

    const getCurrencyConversionDetails = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsCurrency.getCurrencyConversionDetails(currencyId));
        if (response?.status === RESPONSE_STATUS.success) {
              setCurrencyConversionDetails(response.data.data)
        }
        else {
            Toasts.alert(response?.data.message, {autoClose: 3000});
        }
    }

    useEffect(() => {
        getCurrencyData(currencyId);
        getAuditDetails();
        getCurrencyConversionDetails();
    }, [])
    return (
        <>
            {!(currencyData) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">View Currency</h1>
                    <hr className="line" />
                    <div className="all-page-container ">

                        <div style={{ marginTop: '15px' }}>

                        <Row className='view-currency-info'>
                                <Col className="sd-label" size={12} sm={2}>Name </Col>
                                <Col style={{ borderTop: '0px' }}>{currencyData.name}</Col>
                            </Row>

                            <Row className='view-currency-info'>
                                <Col className="sd-label" size={12} sm={2}>Abbreviation </Col>
                                <Col style={{ borderTop: '0px' }}>{currencyData.abbreviation}</Col>
                            </Row>

                            


                        </div>
                        <div>
                            <ButtonRow alignment='right'>
                                <Button purpose='default' onClick={cancelHandler}>Cancel</Button>
                                <Button purpose='primary' onClick={editCurrencyHandler}>Edit</Button>
                            </ButtonRow>
                        </div>

                        <div> 
                        <div style={{marginTop:"20px"}}>
                            <CurrencyCoversionGrid props = {currencyConversionDetails}/>
                             <AuditGrid props={auditDetails} location = {props.location.pathname}/>
                         </div>
                        </div>

                    </div>
                </div>
            )}
        </>
    )
}
export default ViewCurrency;