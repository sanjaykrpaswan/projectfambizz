import React from 'react'
import { Accordion, Card } from 'navex-react/lib/cards'
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { dxReactGrid } from 'navex-react';
import { getFormattedDateTime } from '../../../common/StringUtil';


const { TableHeaderNavbar } =
  dxReactGrid;

export default function CurrencyCoversionGrid(props: any) {



  function capitalize(stringName: any) {
    return stringName && stringName[0].toUpperCase() + stringName.slice(1);
  }

  return (
    <>
      <Accordion
        activeCardIndex={-1}>
        <Card id="CurrencyConversion" title="Conversion Rate">

          <DataGrid
            id="gridContainer"
            dataSource={props.props}
            className="esg-datagrid"
            showBorders={false}
            showColumnLines={false}
            showRowLines={true}
            rowAlternationEnabled={true}
            columnAutoWidth={true}
          >

            <Paging defaultPageSize={10} />
            <Pager
              visible={true}
              showInfo={true}
              showNavigationButtons={true}
            />

            <FilterRow visible={true} />

            <HeaderFilter visible={true} />


            <Column
              dataField="name"
              caption="To Currency"
              sortOrder={"desc"}
            />

            <Column
              dataField="year"
              caption="Year" 
              alignment= "left"
            >
              <HeaderFilter />
            </Column>

           
            <HeaderFilter />

            <Column
              dataField="exchange_rate"
              caption="Rate"
              alignment= "left"
            />
            <HeaderFilter />

          </DataGrid>

        </Card>
      </Accordion>

    </>
  )
}
