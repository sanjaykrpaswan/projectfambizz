import { Card } from "reactstrap";
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { ActionIcon, Button, dxReactGrid, Toasts } from "navex-react";
import 'devextreme/dist/css/dx.light.css';
import { useEffect, useState } from "react";
import { faEye, faPencilAlt, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import '../../../styles/styles.css'
import Loader from "../../../common/loader/Loader";
import { useHistory } from 'react-router-dom';
import LiveExampleContent from "../../../common/PopUp/popModal";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";
const { ResetGridModal ,TableHeaderNavbar} = dxReactGrid;



const Currency = () => {
    const history = useHistory();
    const [resetGridModal, setResetGridModal] = useState(false);
    const [fetchingCurrencyList, setFetchingCurrencyList] = useState(false);
    const [currencyList, setCurrencyList] = useState<any>([]);
    const [currencyId, setCurrencyId] = useState<any>();
    const [showModal, setShowModal] = useState(false);
    const axiosInstance = useAxios();


    const open = (id : any) => {
    setShowModal(true);
    setCurrencyId(id);
  }

  const close = () => setShowModal(false);  

    const toggleResetGridModal = () => {
        setResetGridModal(!resetGridModal);
    };

    /** API call to get the currency list */
    const getCurrencyList = async () => {
        setFetchingCurrencyList(true);
        const response = await axiosInstance.current?.get(apiservice.SettingsCurrency.getCurrencyList());
        if (response?.status === RESPONSE_STATUS.success) {
            setCurrencyList(response.data.data)
            setFetchingCurrencyList(false)
        } else {
            Toasts.alert(response?.data.message)
        }
    }

    

    const currencyViewHandler = (id: any) => {
        window.localStorage.setItem("currencyId", id);
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/currency/viewCurrency`, { data: { currencyId: id } })
    }

    const editCurrencyHandler =(id : any) =>{
        window.localStorage.setItem("currencyId", id);
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/currency/editCurrency`,{currencyId : id });
      }
      
      const addHandler  = () => {
        history.push(
          `/esg/${localStorage.getItem("tanentName")}/settings/currency/addCurrency`
        );
      };
      
      const handleClickedCancel = () => {
        close();
      }
      
      const handleClickedOk = async() =>{
        close();
        const response = await axiosInstance.current?.delete(apiservice.SettingsCurrency.deleteCurrencyById(currencyId));
        if(response?.status === 200){
      
          Toasts.success("Successfully deleted Currency" ,{autoClose:3000}); 
          getCurrencyList();
      
        }else {
          Toasts.alert("Failed to delete the Currency",{autoClose:3000});
        }
      }

    /** Functional component to render action icons in each row of the grid */
    const EditDeleteActionIcons = (id: any) => {
        return (
            <>
                <div>
                    <ActionIcon
                        id="view"
                        icon={faEye}
                        toolTip="View"
                        disabled={false}
                        data-toggle="modal"
                        onClick={()=>currencyViewHandler(id)}
                    />

                    <ActionIcon
                        id="edit"
                        icon={faPencilAlt}
                        toolTip="Edit"
                        disabled={false}
                        data-toggle="modal"
                        onClick={()=>editCurrencyHandler(id)}
                        
                    />

                    <ActionIcon
                        id="deleteGroup"
                        icon={faTrashAlt}
                        toolTip="Delete"
                        disabled={false}
                        data-toggle="modal"
                        onClick={() => open(id)}
                    />
                </div>
            </>
        );
    };

    useEffect(() => {
        getCurrencyList();
    }, [])

    return (
        <>
            <h1 className="esg-page-heading">Currency</h1>
            <hr className="line" />
            <div className="all-page-container ">
                {fetchingCurrencyList ? <Loader style={{ left: "45%", right: "50%", marginTop: "10%" }} /> : (
                    <><Button purpose="primary" style={{ float: "right", marginTop: "15px" }} onClick={addHandler}>Add</Button>
                        <Card style={{marginTop : "55px"}} className="dx-nsg-react-grid survey-table-root dataGrid-card-noheader">
                       
                            <div className="card-header" />
                            <ResetGridModal
                                isOpen={resetGridModal}
                                toggle={toggleResetGridModal} />

                            <DataGrid
                                id="gridContainer"
                                dataSource={currencyList}
                                className="esg-datagrid header-max-width"
                                showBorders={false}
                                showColumnLines={false}
                                showRowLines={true}
                                rowAlternationEnabled={true}
                                columnAutoWidth={true}
                            >
                                <Paging defaultPageSize={10} />
                                <Pager
                                    visible={true}
                                    showInfo={true}
                                    showNavigationButtons={true} />
                                <FilterRow visible={true} />

                                <HeaderFilter visible={true} />
                                <Column
                                    dataField="name"
                                    caption="Name">
                                <HeaderFilter />
                                </Column>
                                <Column
                                    dataField="abbreviation"
                                    caption="Abbreviation">
                                <HeaderFilter />
                                </Column>
                                <Column 
                                    dataField="action_icon"
                                    width={"159px"}
                                    caption="Action"
                                    allowFiltering={false}
                                    allowSorting={false}
                                    cellRender={(e: any) => {
                                        return EditDeleteActionIcons(e.data.id);
                                    }}>
                                </Column>
                            </DataGrid>
                        </Card>
                    </>
                )}
            </div>
            <div>
        <LiveExampleContent
          okButtonText="OK"
          cancelButtonText="Cancel"
          message={'Are you sure you want to  delete the selected Currency?'}
          modalHeading={'Confirm'}
          id=" "
          showModal={showModal}
          handleClickedOk={handleClickedOk}
          handleClickedCancel={handleClickedCancel}
        />
      </div>
        </>
    )
}

export default Currency;
