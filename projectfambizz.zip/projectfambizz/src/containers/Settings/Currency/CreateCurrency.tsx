import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, FormikInput, FormikSelect, FormikOption, Toasts } from 'navex-react'
import './Currency.css'
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { useHistory } from 'react-router-dom';
import { Formik, Form, Field } from 'formik'
import {useState } from 'react';
import Loader from '../../../common/loader/Loader';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const CurrencyAddSchema = Yup.object().shape({
    name: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
    abbreviation: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('field is required'),

})

const CreateCurrency = (props: any) => {

    const [currencyData, setCurrencyData] = useState<any[]>([])
    const [submitClicked,setSubmitClicked] =useState(false)
    const axiosInstance = useAxios();

    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/currency`);
    }

    const handleCurrencySubmit = async (value: any, actions : any) => {
        setSubmitClicked(true);
        const payload = {
            abbreviation : value.abbreviation,
            name : value.name,
            isDeleted : false,
            isDefault : true,
            tenantId : Number(localStorage.getItem("tenantId")) 
          }
        const response = await axiosInstance.current?.post(apiservice.SettingsCurrency.createCurrency(),payload);
        if (response?.status === 200) {
            setCurrencyData(response.data.data)
            Toasts.success(response.data.message, {autoClose: 3000});
            cancelHandler();
        }
        else if (response?.status === 406) {
            setSubmitClicked(false);
            Toasts.alert(response.data.message, {autoClose:3000});
            actions.resetForm();
        }
        else {
            Toasts.alert(response?.data.message, {autoClose:3000});
        }

    }

    return (

        <>
            {!(currencyData && (submitClicked === false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Currency</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'> Add Currency: </h3>
                        <div className="currency-form">
                            <Row style={{ textAlign: 'left' }}>
                                <Formik
                                    initialValues={{
                                        name: '',
                                        abbreviation: '',
                                        submit: true,
                                    }}
                                    validationSchema={CurrencyAddSchema}
                                    onSubmit={handleCurrencySubmit}
                                >
                                    <Form style={{ width: '500px' }}>
                                        <Field
                                            name='name'
                                            required
                                            label='Name'
                                            component={FormikInput}

                                        />
                                        <Field
                                            name='abbreviation'
                                            required
                                            label='Abbreviation'
                                            component={FormikInput}
                                        />
                                        <Row style={{ marginTop: "16px" }}>
                                            <Col size={12} sm={12}>
                                                <ButtonRow alignment="right">
                                                    <Button
                                                        purpose="default"
                                                        onClick={cancelHandler}
                                                    >
                                                        Cancel
                                                    </Button>
                                                    <Button id="save" type="submit" purpose="primary" >
                                                        Save
                                                    </Button>
                                                </ButtonRow>
                                            </Col>
                                        </Row>

                                    </Form>
                                </Formik>

                            </Row>

                        </div>
                    </div>
                </div>

            )}
        </>

    )
}

export default CreateCurrency

