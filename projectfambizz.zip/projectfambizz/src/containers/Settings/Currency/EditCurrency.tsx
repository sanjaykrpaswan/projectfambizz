import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, Toasts, Card } from 'navex-react'
import './Currency.css'
import { useHistory } from 'react-router-dom';
import { useEffect, useState } from 'react';
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { Formik, Form, Field } from 'formik'
import {
    FormikInput
} from 'navex-react/lib/formik'
import Loader from '../../../common/loader/Loader';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const CurrencySchema = Yup.object().shape({
    name: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
    abbreviation: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('field is required'),

})


const EditCurrency = (props: any) => {

    const [currencyData, setCurrencyData] = useState<any>();
    const [submitClicked,setSubmitClicked] =useState(false)
    const axiosInstance = useAxios();

    let temp: any;
    props.location.state === undefined ? temp = window.localStorage.getItem("currencyId") : props.location.state = props.location.state;
    const id = (temp !== undefined ? JSON.parse(temp) : props.location.state.currencyId);

    const getCurrency = async () => {
        const response = await axiosInstance.current?.get(apiservice.SettingsCurrency.getCurrecyById(id));
        if (response?.status === 200) {
            setCurrencyData(response.data.data)
        }
        else {
            Toasts.alert(response?.data.message);
        }
    }

    const handleEditCurrencySubmit = async (value: any) => {
        setSubmitClicked(true)
        const payload = {
            id : id,
            abbreviation : value.abbreviation,
            name : value.name,
            isDeleted : false,
            isDefault : true,
            tenantId : Number(localStorage.getItem("tenantId"))
        }
        const response = await axiosInstance.current?.put(apiservice.SettingsCurrency.updateCurrencyById(),payload);
        if (response?.status === 200) {
            Toasts.success("Successfully updated Currency");
            setSubmitClicked(false)
            cancelHandler();
        }
        else {
            Toasts.alert(response?.data.message);
        }
        
    }

    useEffect((() => {
        getCurrency();
    }), [])

    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/currency`);
    }

    return (
        <>
            {!(currencyData && !submitClicked)  ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (
                <div>
                    <h1 className="esg-page-heading">Currency</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                    <h3 className='esg-page-sub-heading'>Edit Currency : {currencyData.name}</h3>
                        <div className="currency-form">
                            <Row style={{ textAlign: 'left' }}>
                                <Formik
                                    initialValues={{
                                        name: currencyData.name,
                                        abbreviation: currencyData.abbreviation,
                                        submit: true,
                                    }}
                                    validationSchema={CurrencySchema}
                                    onSubmit={handleEditCurrencySubmit}
                                >
                                    <Form style={{ width: '500px' }}>
                                        <Field
                                            name='name'
                                            required
                                            label='Name'
                                            component={FormikInput}
                                        />
                                        <Field
                                            name='abbreviation'
                                            required
                                            label='Abbreviation'
                                            component={FormikInput}
                                        />
                                        <Row style={{ marginTop: "16px" }}>
                                            <Col size={12} sm={12}>
                                                <ButtonRow alignment="right">
                                                    <Button
                                                        purpose="default"
                                                        onClick={cancelHandler}
                                                    >
                                                        Cancel
                                                    </Button>
                                                    <Button id="save" type="submit" purpose="primary" >
                                                        Save
                                                    </Button>
                                                </ButtonRow>
                                            </Col>
                                        </Row>

                                    </Form>
                                </Formik>

                            </Row>

                        </div>
                    </div>
                </div>
            )}

        </>

    )
}

export default EditCurrency

