import { Card, Col, Row } from "reactstrap";
import { Column, DataGrid, FilterRow, HeaderFilter, Pager, Paging, } from "devextreme-react/data-grid";
import { ActionIcon, Button, dxReactGrid, Toasts } from "navex-react";
import 'devextreme/dist/css/dx.light.css';
import { useEffect, useState } from "react";
import { faEye, faPencilAlt, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import '../../../styles/styles.css'
import { useHistory } from 'react-router-dom';
import LiveExampleContent from "../../../common/PopUp/popModal";
import "../UnitGroups/UnitGroups.css"
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import Loader from "../../../common/loader/Loader";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";
const { ResetGridModal } = dxReactGrid;



const UnitGroups = () => {
    const history = useHistory();
    const [resetGridModal, setResetGridModal] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [loadUnitGroupList, setLoadUnitGroupList] = useState(false);
    const [unitGroupData, setUnitGroupData] = useState<any>([]);
    const [unitGroupId, setUnitGroupId] = useState<any>();
    const [tableObj, setTableObj] = useState({});
    const axiosInstance = useAxios();
    let tenantId = localStorage.getItem("tenantId");


    /** API call to get the list of Unit Groups */
    const getUnitGroupList = async () => {

        setLoadUnitGroupList(true);
        const response = await axiosInstance.current?.get(apiservice.SettingsUnitGroups.getUnitGroupsList());
        if (response?.status === RESPONSE_STATUS.success) {
            response?.data?.data?.map((item: any) => {
                item.tempDefaultValue = item.isDefault ? "Default" : "Custom";
            })
            setUnitGroupData(response.data.data)

            setLoadUnitGroupList(false);
        } else {
            Toasts.alert(response?.data.message);
        }

    }

    /** API call to delete the Unit Group by Id */
    const handleClickedOk = async () => {
        close();
        const response = await axiosInstance.current?.delete(apiservice.SettingsUnitGroups.deleteUnitGroupById(unitGroupId));
        if (response?.status === 200) {

            Toasts.success("Successfully deleted Unit Group", { autoClose: 3000 });
            getUnitGroupList();

        } else {
            Toasts.alert("Failed to delete the Unit Group", { autoClose: 3000 });
        }
    }


    useEffect((() => {
        getUnitGroupList();
    }), [])


    const open = (id: any) => {
        setShowModal(true);
        setUnitGroupId(id);
    }


    const close = () => setShowModal(false);

    const toggleResetGridModal = () => {
        setResetGridModal(!resetGridModal);
    };


    const unitGroupsViewHandler = (id: any) => {
        window.localStorage.setItem("unitGroupId", id);
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/viewUnitGroup`, { id: id })
    }


    const handleClickedCancel = () => {
        close();
    }

    const addHandler = () => {
        history.push(
            `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/newUnitGroup`
        );
    };

    const editUnitGroupHandler = (id: any) => {
        window.localStorage.setItem("unitGroupId", id);
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/editUnitGroup`, { unitGroupId: id });
    }




    /** Functional component to render action icons in each row of the grid */
    const EditDeleteActionIcons = (id: any) => {
        return (
            <>
                <div>
                    <ActionIcon
                        id="view"
                        icon={faEye}
                        toolTip="View"
                        disabled={false}
                        data-toggle="modal"
                        onClick={() => { unitGroupsViewHandler(id) }}
                    />

                    <ActionIcon
                        id="edit"
                        icon={faPencilAlt}
                        toolTip="Edit"
                        disabled={false}
                        data-toggle="modal"
                        onClick={() => editUnitGroupHandler(id)}

                    />

                    <ActionIcon
                        id="deleteGroup"
                        icon={faTrashAlt}
                        toolTip="Delete"
                        disabled={false}
                        data-toggle="modal"
                        onClick={() => open(id)}
                    />
                </div>
            </>
        );
    };



    return (
        <>
            <h1 className="esg-page-heading">Unit Groups</h1>
            <hr className="line" />
            <div className="all-page-container ">
                {loadUnitGroupList ? <Loader style={{ left: "45%", right: "50%", marginTop: "10%" }} /> : (
                    <>


                        <Button purpose="primary" className="addUnitGroupButton" onClick={addHandler}  >Add</Button>
                        <Card style={{ marginTop: "55px" }} className="dx-nsg-react-grid unitgroup-table-root dataGrid-card-noheader">

                            <div className="card-header" />
                            <ResetGridModal
                                isOpen={resetGridModal}
                                toggle={toggleResetGridModal} />

                            <DataGrid
                                id="gridContainer"
                                dataSource={unitGroupData}
                                className="esg-datagrid header-max-width"
                                showBorders={false}
                                showColumnLines={false}
                                showRowLines={true}
                                rowAlternationEnabled={true}
                                columnAutoWidth={true}
                            >
                                <Paging defaultPageSize={10} />
                                <Pager
                                    visible={true}
                                    showInfo={true}
                                    showNavigationButtons={true} />
                                <FilterRow visible={true} />

                                <HeaderFilter visible={true} />
                                <Column
                                    dataField="name"
                                    caption="Name"
                                    cellRender={(e: any) => {

                                        if (e.data.isDefault === true) {

                                            return e.data.defaultName;

                                        } else {

                                            return e.data.name
                                        }
                                    }}

                                >

                                    <HeaderFilter />
                                </Column>
                                <Column
                                    dataField="tempDefaultValue"
                                    caption="Type"
                                    cellRender={(e: any) => {

                                        if (e.data.isDefault === true) {

                                            return "Default";

                                        } else {

                                            return "Custom"
                                        }




                                    }}

                                >

                                    <HeaderFilter />
                                </Column>

                                <Column
                                    dataField="action_icon"
                                    caption="Action"
                                    allowFiltering={false}
                                    allowSorting={false}
                                    width={"159px"}
                                    cellRender={(e: any) => {
                                        return EditDeleteActionIcons(e.data.id);
                                    }}>
                                </Column>
                            </DataGrid>
                        </Card>

                    </>
                )}

            </div>
            <div>
                <LiveExampleContent
                    okButtonText="OK"
                    cancelButtonText="Cancel"
                    message={'Are you sure you want to  delete the selected UnitGroup?'}
                    modalHeading={'Confirm'}
                    id=" "
                    showModal={showModal}
                    handleClickedOk={handleClickedOk}
                    handleClickedCancel={handleClickedCancel}
                />
            </div>
        </>
    )
}

export default UnitGroups;
