import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, FormikInput, Toasts } from 'navex-react'
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { useHistory } from 'react-router-dom';
import { Formik, Form, Field } from 'formik'
import UnitDataGrid from './UnitsDataGrid';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import { useEffect, useState } from 'react';
import Loader from '../../../common/loader/Loader';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";


const UnitAddSchema = Yup.object().shape({
    unitGroupName: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
})

const CreateUnitGroups = (props: any) => {

    const [unitGroupData, setUnitGroupData] = useState<any>();
    const [unitGroupId, setUnitGroupId] = useState<any>();
    const [unitsList, setUnitsList] = useState<any>([]);
    const [submitClicked, setSubmitClicked] = useState(false)
    const [unitGroupSaved, setUnitGroupSaved] = useState(false)
    const axiosInstance = useAxios();


    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups`);
    }

    const editHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/editUnitGroup`);
    }

    /** API call to get the Unit Group Details by UnitGroupId */
    const getUnitListByUnitGroupId = async () => {

        const response = await axiosInstance.current?.get(apiservice.SettingsUnitGroups.getUnitListByUnitGroupId(unitGroupData?.id));
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitsList(response.data.data)
         
        } else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
           
        }
    }

    /** API call to save the Unit group */
    const handleUnitGroupSubmit = async (value: any, actions: any) => {
        setSubmitClicked(true);
        const payload = {
            name : value.unitGroupName,
            defaultName : value.unitGroupName,
            isDeleted : false,
            isDefault : false,
            tenantId : Number(localStorage.getItem("tenantId")) 
        }
        const response = await axiosInstance.current?.post(apiservice.SettingsUnitGroups.createUnitGroup(),payload);
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitGroupId(response.data.id);
            setUnitGroupSaved(true);
            setSubmitClicked(false);
            setUnitGroupData(response.data.data)
            Toasts.success(response.data.message, { autoClose: 3000 });
        } else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
            cancelHandler();
        }

    }

    useEffect(() => {
        if ((unitGroupId && unitGroupData) !== undefined) {
            getUnitListByUnitGroupId();
        }
    }, [unitGroupData])

    return (

        <>

            {!((submitClicked === false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (

                <div>
                    <h1 className="esg-page-heading">Unit Groups</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'> Add Unit Groups: </h3>

                        <div className="unit-form">
                            <Row style={{ textAlign: 'left' }}>
                                {unitGroupSaved && (unitGroupData !== undefined) ?
                                    (<><Col className="sd-label" size={12} sm={2}>Name :</Col><Col style={{ borderTop: '0px' }}>{unitGroupData?.isDefault ? unitGroupData?.defaultName : unitGroupData?.name}</Col>

                                    </>)
                                    : (
                                        <Formik
                                            initialValues={{
                                                unitGroupName: '',
                                                submit: true,
                                            }}
                                            validationSchema={UnitAddSchema}
                                            onSubmit={handleUnitGroupSubmit}
                                        >
                                            <Form style={{ width: '500px' }}>
                                                <Field
                                                    name='unitGroupName'
                                                    required
                                                    label='Unit Group Name'
                                                    component={FormikInput}
                                                    disabled={submitClicked}

                                                />

                                                <Row style={{ marginTop: "16px" }}>
                                                    <Col size={12} sm={12}>
                                                        <ButtonRow alignment="right">
                                                            <Button
                                                                purpose="default"
                                                                onClick={cancelHandler}
                                                            >
                                                                Cancel
                                                            </Button>
                                                            <Button id="save" type="submit" purpose="primary" disabled={submitClicked} >
                                                                Save
                                                            </Button>
                                                        </ButtonRow>
                                                    </Col>
                                                </Row>

                                            </Form>
                                        </Formik>
                                    )}
                            </Row>
                            <Row style={{ marginTop: "20px", width: "900px" }}>
                                {(unitGroupSaved && unitsList && unitGroupData) &&
                                    <>
                                        <UnitDataGrid
                                            unitsData={unitsList}
                                            unitGroupId={unitGroupData?.id}
                                            getUnitListByUnitGroupId={getUnitListByUnitGroupId}
                                            //     InProgress={inProgress}
                                            // setInProgress={setInProgress}
                                            isCreate={true} />
                                    </>
                                }
                            </Row>
                        </div>
                        {(unitGroupSaved && unitsList && unitGroupData) &&
                            <div>
                                <ButtonRow alignment='right'>
                                    <Button purpose='default' onClick={cancelHandler}>Cancel</Button>

                                </ButtonRow>
                            </div>}

                    </div>
                </div>

            )}
        </>

    )
}

export default CreateUnitGroups

