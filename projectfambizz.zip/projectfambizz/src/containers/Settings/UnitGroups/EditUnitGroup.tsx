import { Col, Row } from 'reactstrap'
import { ButtonRow, Button, FormikInput, Toasts } from 'navex-react'
import * as Yup from 'yup'
import "../../../styles/styles.css";
import { useHistory } from 'react-router-dom';
import { Formik, Form, Field } from 'formik'
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import { useEffect, useState } from 'react';
import UnitDataGrid from './UnitsDataGrid';
import Loader from '../../../common/loader/Loader';
import "../UnitGroups/UnitGroups.css";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";


const UnitAddSchema = Yup.object().shape({
    unitGroupName: Yup.string().min(2, 'Too Short!').max(100, 'Too Long!').required('field is required'),
})

const EditUnitGroup = (props: any) => {


    const [unitsList, setUnitsList] = useState<any>([]);
    const [unitGroupData, setUnitGroupData] = useState<any>();
    const [editedUnitGroupData, setEditedUnitGroupData] = useState<any>();
    const [submitClicked, setSubmitClicked] = useState(false)
    const [unitGroupSaved, setUnitGroupSaved] = useState(false)
    const axiosInstance = useAxios();

    const history = useHistory();

    let temp: any;
    props.location.state === undefined ? temp = window.localStorage.getItem("unitGroupId") : props.location.state = props.location.state;
    const id = (temp !== undefined ? JSON.parse(temp) : props.location.state.unitGroupId);

    /** API call to get the list of Units by UnitGroupId */
    const getUnitListByUnitGroupId = async () => {

        const response = await axiosInstance.current?.get(apiservice.SettingsUnitGroups.getUnitListByUnitGroupId(id));
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitsList(response.data.data)
        } else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }

    }

    /** API call to get the Unit Group Details by UnitGroupId */
    const getUnitGroupDetailsById = async () => {

        const response = await axiosInstance.current?.get(apiservice.SettingsUnitGroups.getUnitGroupById(id));
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitGroupData(response.data.data);

        } else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }

    }

    /** API call to save the updated unit group by Id */
    const handleEditUnitGroupSubmit = async (value: any) => {
        setSubmitClicked(true);
        const payload = {
            id : id,
            name : value.unitGroupName,
            defaultName : value.unitGroupName,
            isDeleted : false,
            isDefault : false,
            tenantId : Number(localStorage.getItem("tenantId")) 
        }
        const response = await axiosInstance.current?.put(apiservice.SettingsUnitGroups.updateUnitGroupById(),payload);
        if (response?.status === 200) {
            Toasts.success(response.data.message, { autoClose: 3000 });
            setUnitGroupSaved(true);
            setEditedUnitGroupData(response.data.data)
            setSubmitClicked(false);
            cancelHandler();
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }

    }


    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups`);
    }


    useEffect((() => {
        getUnitListByUnitGroupId();
        getUnitGroupDetailsById();

    }), [])

    return (

        <>
            {!(unitGroupData && unitsList && (submitClicked == false)) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (

                <div>
                    <h1 className="esg-page-heading">Unit Groups</h1>
                    <hr className="line" />
                    <div className="all-page-container">
                        <h3 className='esg-page-sub-heading'> Edit Unit Groups: </h3>

                        <div className="unitGroup-form">




                            {/* <Button purpose='default' onClick={cancelHandler}>Cancel</Button>
                                        <Button purpose='primary' onClick={editHandler}>Edit</Button> */}

                            <Formik
                                initialValues={{
                                    unitGroupName: unitGroupData.isDefault ? unitGroupData.defaultName : unitGroupData.name,
                                    submit: true,
                                }}
                                validationSchema={UnitAddSchema}
                                onSubmit={handleEditUnitGroupSubmit}
                            >
                                <Form >
                                    <Row>

                                        <Field
                                            name='unitGroupName'
                                            required
                                            label='Unit Group Name'
                                            component={FormikInput}
                                            width={"300px"}

                                        />



                                    </Row>



                                    <Row style={{ marginTop: "20px", width: "900px" }}>

                                        <UnitDataGrid
                                            unitsData={unitsList}
                                            unitGroupId={id}
                                            isCreate={false}
                                            getUnitListByUnitGroupId={getUnitListByUnitGroupId}
                                        />

                                    </Row>

                                    <Row style={{ marginTop: "16px" }}>
                                        <Col >
                                            <ButtonRow alignment="right">
                                                <Button
                                                    purpose="default"
                                                    onClick={cancelHandler}
                                                >
                                                    Cancel
                                                </Button>
                                                <Button id="save" type="submit" purpose="primary" disabled={submitClicked} >
                                                    Save
                                                </Button>
                                            </ButtonRow>
                                        </Col>
                                    </Row>
                                </Form>
                            </Formik>


                        </div>


                    </div>
                </div>

            )}
        </>

    )
}

export default EditUnitGroup

