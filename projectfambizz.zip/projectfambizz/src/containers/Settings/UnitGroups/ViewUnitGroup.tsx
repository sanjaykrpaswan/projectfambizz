import { Card, Col, Row } from 'reactstrap'
import { ButtonRow, Button, dxReactGrid, Toasts } from 'navex-react'
import { useHistory } from 'react-router-dom';
import "../../../styles/styles.css";
import { useEffect, useState } from 'react';
import { RESPONSE_STATUS } from '../../../common/responseStatus';
import Loader from '../../../common/loader/Loader';
import DataGrid, { Column, FilterRow, HeaderFilter, Pager, Paging } from 'devextreme-react/data-grid';
import {AuditGrid} from '../Audit/AuditGrid';
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";
const { ResetGridModal, TableHeaderNavbar } = dxReactGrid;


const ViewUnitGroup = (props: any) => {

    const axiosInstance = useAxios();
    const [unitsList, setUnitsList] = useState<any>([]);
    const [unitGroupData, setUnitGroupData] = useState<any>();
    const [resetGridModal, setResetGridModal] = useState(false);
    const [auditDetails, setAuditDetails] = useState<any>([]);    
    let tenantId = localStorage.getItem("tenantId");
    let unitGroupAuditDetails:any =[];
    let temp: any;
    props.location.state === undefined ? temp = window.localStorage.getItem("unitGroupId") : props.location.state = props.location.state;
    const id = (temp !== undefined ? JSON.parse(temp) : props.location.state.id);


    /** API call to get the list of Units by UnitGroupId */
    const getUnitListByUnitGroupId = async () => {

        const response = await axiosInstance.current?.get(apiservice.SettingsUnitGroups.getUnitListByUnitGroupId(id));
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitsList(response.data.data)
        } else {
            Toasts.alert(response?.data.message, {autoClose: 3000});
        }

    }

    /** API call to get the audit details of unit group */
    const getAuditDetails = async () => {
        const response = await axiosInstance.current?.get(apiservice.Audit.auditDetails('unit_groups',  id, tenantId));
        if (response?.status === RESPONSE_STATUS.success) {
            response?.data?.data?.map((item: any) => {
                item.tempOldValue = JSON.stringify(item.oldValue)
                item.tempNewValue = JSON.stringify(item.newValue)
            })
            response?.data?.data.forEach((data:any, index:any) => {
                unitGroupAuditDetails.push(data);
            });
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }
    }

    /** API call to get the audit details of unit by parentId */
    const getUnitAuditDetails = async () => {
        const response = await axiosInstance.current?.get(apiservice.Audit.auditDetailsByParentId('unit', id, tenantId));
        if (response?.status === RESPONSE_STATUS.success) {
            response?.data?.data?.map((item: any) => {
                item.tempOldValue = JSON.stringify(item.oldValue)
                item.tempNewValue = JSON.stringify(item.newValue)
            })
            setAuditDetails(response.data.data.concat(unitGroupAuditDetails))
        }
        else {
            Toasts.alert(response?.data.message, { autoClose: 3000 });
        }
    }

    /** API call to get the Unit Group Details by UnitGroupId */
    const getUnitGroupDetailsById = async () => {

        const response = await axiosInstance.current?.get(apiservice.SettingsUnitGroups.getUnitGroupById(id));
        if (response?.status === RESPONSE_STATUS.success) {
            setUnitGroupData(response.data.data)
        } else {
            Toasts.alert(response?.data.message);
        }

    }


    useEffect(() => {
        getUnitListByUnitGroupId();
        getUnitGroupDetailsById();
        getAuditDetails();
        getUnitAuditDetails();
    }, [])

    const toggleResetGridModal = () => {
        setResetGridModal(!resetGridModal);
    };


    const history = useHistory();

    const cancelHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups`);
    }

    const editHandler = () => {
        history.push(`/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/editUnitGroup`);
    }

    let title = (
        <div className="parenttitle">
            <div className="titlename">Units</div>

        </div>
    );

    return (
        <>

            {!(unitGroupData && unitsList) ? <Loader style={{ left: "50%", right: "50%", top: "40%", bottom: "40%", position: "absolute" }} /> : (

                <div>
                    <h1 className="esg-page-heading">Unit Group</h1><hr className="line" /><div className="all-page-container">

                        <Row className='view-resource-info'>
                            <Col className="sd-label" size={12} sm={2}>Name </Col>
                            <Col style={{ borderTop: '0px' }}>{unitGroupData.isDefault ? unitGroupData.defaultName : unitGroupData.name}</Col>
                        </Row>



                        <>
                            <Card style={{ marginTop: "55px" }} className="dx-nsg-react-grid units-table-root dataGrid-card-noheader">
                                <TableHeaderNavbar tableTitle={title} />
                                <div className="card-header" />
                                <ResetGridModal
                                    isOpen={resetGridModal}
                                    toggle={toggleResetGridModal} />

                                <DataGrid
                                    id="gridContainer"
                                    dataSource={unitsList}
                                    className="esg-datagrid header-max-width"
                                    showBorders={false}
                                    showColumnLines={false}
                                    showRowLines={true}
                                    rowAlternationEnabled={true}
                                    columnAutoWidth={true}
                                >
                                    <Paging defaultPageSize={10} />
                                    <Pager
                                        visible={true}
                                        showInfo={true}
                                        showNavigationButtons={true} />
                                    <FilterRow visible={true} />

                                    <HeaderFilter visible={true} />
                                    <Column
                                        dataField="extendedName"
                                        caption="Name">
                                        <HeaderFilter />
                                    </Column>
                                    <Column
                                        dataField="abbreviation"
                                        caption="Abbreviation"
                                    >
                                        <HeaderFilter />
                                    </Column>

                                </DataGrid>
                            </Card>
                        </>

                        <div>
                            <ButtonRow alignment='right'>
                                <Button purpose='default' onClick={cancelHandler}>Cancel</Button>
                                <Button purpose='primary' onClick={editHandler} >Edit</Button>
                            </ButtonRow>
                        </div>

                        <div style={{marginTop:"20px"}}>                                                   
                            <AuditGrid props={auditDetails === undefined? unitGroupAuditDetails : auditDetails} location = {props.location.pathname} />                           
                        </div>
                        
                    </div>


                </div>
            )}

        </>
    )

}

export default ViewUnitGroup


