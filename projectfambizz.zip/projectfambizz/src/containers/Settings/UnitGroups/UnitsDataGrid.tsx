import { Toasts } from "navex-react";
import { FC, useState } from "react";
import InlineEditDataGrid from "../../../common/InlineEditDataGrid";
import Loader from "../../../common/loader/Loader";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

let TableColumns1 = [
  { name: "extendedName", title: "Name" },
  { name: "abbreviation", title: "Abbreviation" },

];

export const UnitDataGrid: FC<any> = (props: any) => {

  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [inProgress, setInProgress] = useState<boolean>(false);
  const axiosInstance = useAxios();


  /** API call to create a Unit  */
  const handleCreateInsert = async (values: any) => {
    setInProgress(true);
    const payload = {
      abbreviation : values.abbreviation,
      extendedName : values.extendedName,
      isDeleted : false,
      unitGroupsId : Number(props.unitGroupId),
      tenantId : Number(localStorage.getItem("tenantId"))         
    }
    const response = await axiosInstance.current?.post(apiservice.SettingsUnits.createUnit(),payload);
    if (response?.status === 200) {
  
      props.getUnitListByUnitGroupId()
      setInProgress(false);
      Toasts.success(response.data.message, { autoClose: 3000 });
    } else {
      setInProgress(false);
      Toasts.alert(response?.data.message, { autoClose: 3000 });
    }
  }

  /** API call to update Unit  */
  const handleEditInsert = async (key: any, values: any) => {
    const updatedName = values.extendedName ? values.extendedName : key.extendedName;
    const updatedAbbreviation = values.abbreviation ? values.abbreviation : key.abbreviation;
    setInProgress(true);
    const payload = {
      id : key.id,
      abbreviation : updatedAbbreviation,
      extendedName : updatedName,
      isDeleted : false,
      unitGroupsId: Number(key.unitGroupsId),
      tenantId : Number(localStorage.getItem("tenantId"))
    }
    const response = await axiosInstance.current?.put(apiservice.SettingsUnits.updateUnitById(),payload);
    if (response?.status === 200) {
      props.getUnitListByUnitGroupId()
    
      Toasts.success(response.data.message, { autoClose: 3000 });
      setInProgress(false);
    } else {
      setInProgress(false);
      Toasts.alert(response?.data.message, { autoClose: 3000 });
    }
  }

  /** API call to delete the Unit */
  const handleDelete = async (values: any) => {
    setInProgress(true)
    const response = await axiosInstance.current?.delete(apiservice.SettingsUnits.deleteUnitById(values));
    if (response?.status === 200) {
      props.getUnitListByUnitGroupId()
   
      Toasts.success(response.data.message, { autoClose: 3000 });
      setInProgress(false);

    } else {
      setInProgress(false);
      Toasts.alert(response?.data.message, { autoClose: 3000 });
    }
  }




  const handleSave = (values: any) => {

    if (values.changes[0].type === "insert") {
      handleCreateInsert(values.changes[0].data);
    } else if (values.changes[0].type === "update") {
      handleEditInsert(values.changes[0].key, values.changes[0].data);
    } else {
      handleDelete(values.changes[0].key.id);
    }
    setIsSaved(true);
  }


  return (
    <>
      {inProgress ? <Loader style={{ left: "50%", right: "50%", top: "90%", bottom: "10%", position: "absolute" }} /> : (
        <InlineEditDataGrid
          columns={TableColumns1}
          gridData={props.unitsData}
          gridTitle={"Units"}
          isFilterRow
          isHeaderBar
          isHeaderFilter
          onSave={handleSave}
          allowUpdate
          showOnlyAdd
          allowAdd
          allowDelete


        />
      )}
    </>
  );
};

export default UnitDataGrid;
