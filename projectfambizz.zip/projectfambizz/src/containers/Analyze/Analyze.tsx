import "./Analyze.css";
import { Helmet } from "react-helmet";

const Analyze = (props: any) => {
  return (
    <>
      <Helmet>
        <title>Analyze</title>
      </Helmet>
      <h1 className="esg-page-heading">Analyze</h1>
      <hr className="line" />
      <div className="all-page-container">
      </div>
    </>
  );
};

export default Analyze;
