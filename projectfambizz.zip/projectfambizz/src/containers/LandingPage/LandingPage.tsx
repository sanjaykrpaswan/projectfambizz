import "./LandingPage.css";
import { Helmet } from "react-helmet";

const LandingPage = (props: any) => {
  return (
    <>
      <Helmet>
        <title>My ESG</title>
      </Helmet>
      <h1 className="esg-page-heading">My ESG</h1>
      <hr className="line" />
      <div className="all-page-container"></div>
    </>
  );
};

export default LandingPage;
