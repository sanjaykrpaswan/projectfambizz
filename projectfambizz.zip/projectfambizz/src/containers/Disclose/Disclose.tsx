import "./Disclose.css";
import { Helmet } from "react-helmet";
import DataGridGrouping from "../../common/DataGridGrouping";
import { CollectionData } from "../../data/CollectionData";
import InlineEditDataGrid from "../../common/InlineEditDataGrid";
import Select from "react-select";
import { Col, Row } from "reactstrap";

let TableColumns1 = [
  { name: "aliasName", title: "Asset Id" },
  { name: "name", title: "Asset" },
  { name: "resourceName", title: "Resource Type" },
  { name: "assetType", title: "Asset Type" },
];

const Disclose = (props: any) => {

  const options = [
    { value: "chocolate", label: "Chocolate" },
    { value: "strawberry", label: "Strawberry" },
    { value: "mango", label: "Mango" },
    { value: "banana", label: "Banana" },
    { value: "vanilla", label: "Vanilla" },
    { value: "orange", label: "Orange" },
    { value: "berry", label: "Berry" },
    { value: "lichi", label: "Lichi" },
    { value: "apple", label: "Apple" },
    { value: "apricot", label: "Apricot" },
    { value: "grape", label: "Grape" },
    { value: "papaya", label: "Papaya" },
    { value: "pineaple", label: "Pineaple" },
  ];

  const handleSave = (values: any) => {
  };
  return (
    <>
      <Helmet>
        <title>Disclose</title>
      </Helmet>
      <h1 className="esg-page-heading">Disclose</h1>
      <hr className="line" />
      <div className="all-page-container">
        <DataGridGrouping
          columns={TableColumns1}
          gridData={CollectionData.data}
          gridTitle={"Grouping Data Grid"}
          isFilterRow
          isHeaderBar
          isHeaderFilter
        />
        <InlineEditDataGrid
          columns={TableColumns1}
          gridData={CollectionData.data}
          gridTitle={"Inline Edit Data Grid"}
          isFilterRow
          isHeaderBar
          isHeaderFilter
          onSave={handleSave}
          allowUpdate
          allowAdd
          allowDelete
        />
        <Row style={{marginBottom:"20px"}}>
          <Col sm={4}>
            <Select
              defaultValue={[options[2], options[3]]}
              isMulti
              name="colors"
              options={options}
            />
          </Col>
        </Row>
      </div>
    </>
  );
};

export default Disclose;
