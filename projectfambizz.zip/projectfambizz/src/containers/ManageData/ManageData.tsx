import "./ManageData.css";
import { Helmet } from "react-helmet";

const ManageData = (props: any) => {
  return (
    <>
      <Helmet>
        <title>Manage Data</title>
      </Helmet>
      <h1 className="esg-page-heading">Manage Data</h1>
      <hr className="line" />
      <div className="all-page-container"></div>
    </>
  );
};

export default ManageData;
