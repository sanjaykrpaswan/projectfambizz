import { Col, Row } from "reactstrap";
import { ButtonRow, Button, Toasts } from "navex-react";
import "./../ManageData.css";
import { useHistory } from "react-router-dom";
import { useEffect, useState } from "react";
import Loader from "../../../common/loader/Loader";
import "../../../styles/styles.css";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const ViewAsset = (props: any) => {
  const [assetData, setAssetData] = useState<any>();
  const axiosInstance = useAxios();

  const history = useHistory();

  let temp: any;
  if (props.location.state === undefined) {
    temp = window.localStorage.getItem("assetId");
  }
  const id = temp !== undefined ? JSON.parse(temp) : props.location.state.id;

  /** API call to get the details of Asset */
  const getAssetDetails = async () => {
    const response = await axiosInstance.current?.get(apiservice.DataCollection.getAssetById(id));
    if (response?.status === RESPONSE_STATUS.success) {
      setAssetData(response.data.data);
    } else {
      Toasts.alert(response?.data.message, { autoClose: 3000 });
    }
  };

  useEffect(() => {
    getAssetDetails();
  }, []);

  const cancelHandler = () => {
    history.push(
      `/esg/${localStorage.getItem("tanentName")}/datacollection/collection`
    );
  };

  const editHandler = () => {
    history.push(
      `/esg/${localStorage.getItem(
        "tanentName"
      )}/datacollection/collection/editAsset`,
      { assetId: id }
    );
  };

  return (
    <>
      {!assetData ? (
        <Loader
          style={{
            left: "50%",
            right: "50%",
            top: "40%",
            bottom: "40%",
            position: "absolute",
          }}
        />
      ) : (
        <div>
          <h1 className="esg-page-heading">Asset Details</h1>
          <hr className="line" />
          <div className="all-page-container">
            <div style={{ marginTop: "15px" }}>
              <Row className="view-asset-info">
                <Col className="ad-label" size={12} sm={2}>
                  Asset Name
                </Col>
                <Col style={{ borderTop: "0px" }}>{assetData.name}</Col>
              </Row>
              <Row className="view-asset-info">
                <Col className="ad-label" size={12} sm={2}>
                  Asset ID
                </Col>
                <Col style={{ borderTop: "0px" }}>{assetData.aliasName}</Col>
              </Row>
              <Row className="view-asset-info">
                <Col className="ad-label" size={12} sm={2}>
                  Asset Type
                </Col>
                <Col style={{ borderTop: "0px" }}>{assetData.assetType}</Col>
              </Row>
            </div>
            <div>
              <ButtonRow alignment="right">
                <Button purpose="default" onClick={cancelHandler}>
                  Cancel
                </Button>
                <Button purpose="primary" onClick={editHandler}>
                  Edit
                </Button>
              </ButtonRow>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ViewAsset;
