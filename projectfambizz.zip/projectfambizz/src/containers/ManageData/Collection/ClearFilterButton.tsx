import { FC } from "react";
import { Col } from "reactstrap";
import { Button } from "navex-react";

export const ClearFilterButton: FC<any> = (props: any) => {
  return (
    <>
      <Col size={12} sm={2}>
        <Button
          data-testid={props.testId}
          purpose="default"
          onClick={props.clearFilterHandler}
          style={{ marginTop: "23px", marginLeft: "10px" }}
        >
          Clear Filters
        </Button>
      </Col>
    </>
  );
};
export default ClearFilterButton;
