import { ActionIcon, Button } from "navex-react";
import { FC } from "react";
import { Col, Row } from "reactstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPlus,
  faDatabase,
  faGlassWhiskey
} from "@fortawesome/free-solid-svg-icons";

export const QuickAction: FC<any> = (props: any) => {
  return (
    <>
      <Row style={{ marginBottom: "30px" }}>
        <Col size={12} sm={2}>
          <Button
            className="quick-button"
            purpose="default"
          >
            <FontAwesomeIcon className="quick-icons" icon={faPlus} />
            Add Data
          </Button>
        </Col>
        <Col size={12} sm={2}>
          <Button
            className="quick-button"
            purpose="default"
          >
            <FontAwesomeIcon className="quick-icons" icon={faGlassWhiskey} />
            Manage Entities
          </Button>
        </Col>
        <Col size={12} sm={3}>
          <Button
            className="quick-button"
            purpose="default"
          >
            <FontAwesomeIcon className="quick-icons" icon={faDatabase} />
            Manage Data Associations
          </Button>
        </Col>
      </Row>
    </>
  );
};
export default QuickAction;
