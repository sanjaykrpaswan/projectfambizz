import { FC, useState } from "react";
import { Col } from "reactstrap";
import { DropDown, DropDownItem } from "navex-react/lib/dropDown";


export const CollectionDropDown: FC<any> = (props: any) => {


  const [resourceData, setResourceData] = useState<any>([]);


  console.log("resource", resourceData);

  return (
    <>
      <Col size={12} sm={3}>
        <DropDown
          id="resourceType"
          label="Resource Type"
          value={props.resourceTypeId}
          title={props.getResourceTypeName(props.resourceTypeId)}
          onChange={(value: any) => props.setResourceTypeId(value)}
          maxMenuHeight={"50px" && "186px"}
          forceWidth
          vScrollAfter={100}
          isFormControl
        >
          {Object.values(props.resourceType).map((prov: any): any => {
            return (
              <DropDownItem value={prov.key} key={prov.key}  >
                {prov.name}
              </DropDownItem>
            );
          })}
        </DropDown>
      </Col>
      <Col size={12} sm={3}>
        <DropDown
          id="assetType"
          label="Asset Type"
          value={props.assetTypeId}
          title={props.getAssetTypeName(props.assetTypeId)}
          onChange={(value: any) => props.setAssetTypeId(value)}
          maxMenuHeight={"50px" && "186px"}
          forceWidth
          vScrollAfter={100}
          isFormControl
        >
          {props.assetType.map((prov: any): any => {
            return (
              <DropDownItem value={prov.key} key={prov.key}>
                {prov.value}
              </DropDownItem>
            );
          })}
        </DropDown>
      </Col>
    </>
  );
};
export default CollectionDropDown;
