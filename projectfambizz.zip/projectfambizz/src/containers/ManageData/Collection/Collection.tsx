import "../ManageData.css";
import { Helmet } from "react-helmet";
import CollectionDataGrid from "./CollectionDataGrid";
import { useEffect, useState } from "react";
import PageHeader from "../../../common/PageHeader";
import { Toasts } from "navex-react";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";
import QuickAction from "./QuickAction";



const Collection = (props: any) => {

  const [assetData, setAssetData] = useState<any>([]);

  const [dataGridLoader, setDataGridLoader] = useState(false);
  const axiosInstance = useAxios();


  const manageData = async () => {
    setDataGridLoader(true);
    const response = await axiosInstance.current?.get(apiservice.DataCollection.getAssetDetailsList())
    if (response?.status === RESPONSE_STATUS.success) {
        setAssetData(response.data.data)
        setDataGridLoader(false);
    } else {
        Toasts.alert(response?.data.message);
        setDataGridLoader(false);
    }
}


  useEffect(() => {
    manageData();
  }, []);


  return (
    <>
      <Helmet>
        <title>Manage Data</title>
      </Helmet>
      <PageHeader heading="Collection" testId="collection-header" />
      <hr className="line" />
      <div className="all-page-container">
        <div className="container-Dropdown">
        <h3 className="action-heading">Quick Actions</h3>
        <QuickAction />
          <div className="assignedQuestionTable">
          <h3 className="action-heading">View/Edit Data</h3>
            <CollectionDataGrid
              gridData={assetData}
              InProgress={dataGridLoader}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default Collection;
