
import { FC, useState } from "react";
import { useHistory } from 'react-router-dom';
import Card from "reactstrap/lib/Card";
import {
  Column,
  DataGrid,
  FilterRow,
  HeaderFilter,
  Pager,
  Paging,
} from "devextreme-react/data-grid";
import { ActionIcon, dxReactGrid } from "navex-react";
import { Loader } from "../../../common/loader/Loader";
import "../../../styles/styles.css";
import "../ManageData.css";
import "devextreme/dist/css/dx.light.css";
import {
  faDownload,
  faEye,
  faPencilAlt,
  faTrashAlt,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const { TableHeaderNavbar, HiddenColumnChooserModal, ResetGridModal } =
  dxReactGrid;

interface IColumnExtension {
  columnName: string;
  togglingEnabled: boolean;
}

const defaultHiddenColumnNames = ["created"];
const ColumnExtensions: IColumnExtension[] = [
  { columnName: "Asset Id", togglingEnabled: false },
];

let TableColumns = [
  { name: "aliasName", title: "Asset Id" },
  { name: "name", title: "Asset" },
  { name: "resourceName", title: "Resource Type" },
  { name: "assetType", title: "Asset Type" },
  { name: "emissionName", title: "Emission Name" },
];

export const CollectionDataGrid: FC<any> = (props: any) => {
  const history = useHistory();
  
  const [resetGridModal, setResetGridModal] = useState(false);
  const [columnChooserModal, setColumnChooserModal] = useState(false);
  const [dynamicTableHeaders, setDynamicTableHeaders] = useState<any>(TableColumns);
  const [hiddenColumnNames, setHiddenColumnNames] = useState(
    defaultHiddenColumnNames
  );

  //set dynamic column when we choose in setings
  const toggleColumnChooserModal = () => {
    setColumnChooserModal(!columnChooserModal);
  };

  //defined setting menu items
  const settingsMenuItems: any[] = [
    {
      value: "column_selection",
      onClick: () => {
        toggleColumnChooserModal();
      },
      displayText: "Show/Hide Columns",
    },
    {
      value: "reset",
      onClick: () => {
        toggleResetGridModal();
      },
      displayText: "Reset to Default",
    },
  ];

  //Handle click for Reset in setting menu
  const toggleResetGridModal = () => {
    setResetGridModal(!resetGridModal);
  };

  //Handle reset Grid data
  const resetGridStateToDefault = () => {
 
  };

  //Handle hidden column model changes
  const setHiddenColumnsNames = (_hiddenColumnNames: string[]) => {
    setHiddenColumnNames(_hiddenColumnNames);
  };

  let title = (
    <div className="parenttitle">
      <div className="titlename">Environmental Data</div>
      <div className="downloadIcon"><FontAwesomeIcon icon={faDownload} color="#3265d7" /></div>
    </div>
  );

  //Render dynamic colums
  const renderDynamicHeaders = (items: any) => {
    return (
      !hiddenColumnNames.includes(items.name) && (
        <Column
          dataField={items.name}
          caption={items.title}
          alignment={"left"}
          key={items.name}
        />
      )
    );
  };

  const EditDeleteActionIcons = (id: any) => {
    return (
      <>
        <div>
          <ActionIcon
            id="view"
            icon={faEye}
            toolTip="View"
            disabled={false}
            data-toggle="modal"
            onClick={() => { viewAssetHandler(id) }}
          />

          <ActionIcon
            id="edit"
            icon={faPencilAlt}
            toolTip="Edit"
            disabled={false}
            data-toggle="modal"
          />

          <ActionIcon
            id="deleteGroup"
            icon={faTrashAlt}
            toolTip="Delete"
            disabled={false}
            data-toggle="modal"
          />
        </div>
      </>
    );
  };

  const viewAssetHandler = (id: any) => {
    window.localStorage.setItem("assetId", id);
    history.push(`/esg/${localStorage.getItem("tanentName")}/datacollection/collection/viewAsset`, { id: id });
  }

  return (
    <>
      <Card className="dx-nsg-react-grid survey-table-root dataGrid-card-noheader setting-export-icon">
        <div className="card-header" data-testid="collectionTestGrid" />
        <ResetGridModal
          isOpen={resetGridModal}
          toggle={toggleResetGridModal}
          onResetGrid={resetGridStateToDefault}
        />
        <TableHeaderNavbar
          tableTitle={title}
          addShow={true}
          settingsMenu={settingsMenuItems}
          settingsMenuToolTip="Settings"
        />
        <HiddenColumnChooserModal
          isOpen={columnChooserModal}
          toggle={toggleColumnChooserModal}
          tableColumns={dynamicTableHeaders}
          hiddenColumns={hiddenColumnNames}
          columnExtensions={ColumnExtensions}
          onColumnVisibleChange={setHiddenColumnsNames}
        />
        {props.InProgress ? (
          <Loader style={{ left: "50%", right: "50%" }} />
        ) : (
          <DataGrid
            id="gridContainer"
            dataSource={props.gridData}
            className="esg-datagrid header-max-width"
            showBorders={false}
            showColumnLines={false}
            showRowLines={true}
            rowAlternationEnabled={true}
            columnAutoWidth={true}
          >
            <Paging defaultPageSize={10} />
            <Pager
              visible={true}
              showInfo={true}
              showNavigationButtons={true}
            />
            <FilterRow visible={true} />
            <HeaderFilter visible={true} />

            {dynamicTableHeaders &&
              Object.entries(dynamicTableHeaders).map((items: any) =>
                renderDynamicHeaders(items[1])
              )}
            <Column
              caption="Action"
              allowFiltering={false}
              allowSorting={false}
              cellRender={(e: any) => {
                return EditDeleteActionIcons(e.data.id);
              }}
            ></Column>
          </DataGrid>
        )}
      </Card>
    </>
  );
};
export default CollectionDataGrid;
