import { Col, Row } from "reactstrap";
import { ButtonRow, Button, Toasts } from "navex-react";
import { useHistory } from "react-router-dom";
import { useEffect, useState } from "react";
import "../../../styles/styles.css";
import { Formik, Form, Field } from "formik";
import { FormikInput } from "navex-react/lib/formik";
import Loader from "../../../common/loader/Loader";
import { RESPONSE_STATUS } from "../../../common/responseStatus";
import { useAxios } from "../../../services/useAxios";
import apiservice from "../../../services/apiservice";

const EditAsset = (props: any) => {
  const [assetData, setAssetData] = useState<any>();
  const [submitClicked, setSubmitClicked] = useState(false);
  const axiosInstance = useAxios();

  const history = useHistory();

  let temp: any;
  if (props.location.state === undefined) {
    temp = window.localStorage.getItem("assetId");
  }
  const id =
    temp !== undefined ? JSON.parse(temp) : props.location.state.assetId;

  /** API call to get the details of Asset */
  const getAssetDetails = async () => {
    const response = await axiosInstance.current?.get(apiservice.DataCollection.getAssetById(id));
    if (response?.status === RESPONSE_STATUS.success) {
      setAssetData(response.data.data);
    } else {
      Toasts.alert(response?.data.message, { autoClose: 3000 });
    }
  };

  useEffect(() => {
    getAssetDetails();
  }, []);

  const cancelHandler = () => {
    history.push(
      `/esg/${localStorage.getItem(
        "tanentName"
      )}/datacollection/collection/viewAsset`,
      { id: id }
    );
  };

  return (
    <>
      {!(assetData && submitClicked === false) ? (
        <Loader
          style={{
            left: "50%",
            right: "50%",
            top: "40%",
            bottom: "40%",
            position: "absolute",
          }}
        />
      ) : (
        <div>
          <h1 className="esg-page-heading">Asset</h1>
          <hr className="line" />
          <div className="all-page-container">
            <h3 className="esg-page-sub-heading">
              Edit Asset : {assetData.name}
            </h3>
            <div style={{ marginTop: "60px" }}>
              <Row style={{ textAlign: "left" }}>
                <Formik
                  initialValues={{
                    name: assetData.name,
                    aliasName: assetData.aliasName,
                    assetType: assetData.assetType,
                    submit: true,
                  }}
                  onSubmit={(e) => console.log("Clicked edit", e)}
                >
                  {({
                    values,
                    errors,
                    touched,
                    isSubmitting,
                    setFieldValue,
                  }) => (
                    <Form style={{ width: "500px" }}>
                      <Field
                        name="name"
                        required
                        label="Asset Name"
                        component={FormikInput}
                      />

                      <Field
                        name="aliasName"
                        label="Asset ID"
                        required
                        component={FormikInput}
                      />
                      <Field
                        name="assetType"
                        required
                        label="Asset Type"
                        component={FormikInput}
                      />
                      <Row style={{ marginTop: "16px" }}>
                        <Col size={12} sm={12}>
                          <ButtonRow alignment="right">
                            <Button purpose="default" onClick={cancelHandler}>
                              Cancel
                            </Button>
                            <Button id="save" type="submit" purpose="primary">
                              Save
                            </Button>
                          </ButtonRow>
                        </Col>
                      </Row>
                    </Form>
                  )}
                </Formik>
              </Row>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default EditAsset;
