import React, { useEffect, useState } from "react";
import "./App.css";
import "./styles/styles.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import ESGNavigationUI from "./components/Navigation/ESGNavigationUI";
import { ToastsContainer } from "navex-react";
import { useAuth } from "react-oidc-context";
import { RESPONSE_STATUS } from "./common/responseStatus";
import { useAxios } from "./services/useAxios";
import apiservice from "./services/apiservice";



const App = () => {

  const auth = useAuth();
  const axiosInstance = useAxios();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
   //to be further implemented, based on userRoles
   const getPortalsData = async () => {
    
    
    const retries = 3;
    for (var i = 0; i < retries; i++) {
      const response = await axiosInstance.current?.get(apiservice.Portal.getPortalData());
      if (response && response.data && response.status === RESPONSE_STATUS.success) {
        localStorage.setItem("userData", JSON.stringify(response.data));
        localStorage.setItem(
          "tenantId",
          JSON.stringify(response.data.tenantId)
        );
        i=retries;//if success loop out
      }
    }
  };

  useEffect(() => {
    if (!auth.isAuthenticated){
      console.log("undifined axios instance ");
      return;
    } 
    getPortalsData();
  }, [auth.isAuthenticated]);

    switch (auth.activeNavigator) {
        case "signinSilent":
            return <div>Signing you in...</div>;
        case "signoutRedirect":
            return <div>Signing you out...</div>;
    }

    if (auth.isLoading) {
        return <div>Loading...</div>;
    }

    if (auth.error) {
        return <div>Oops... {auth.error.message}</div>;
    }

    if (auth.isAuthenticated) {
      return (
        <>
          <ToastsContainer />
          <Router>
            <Switch>
              <Route path="/login" component={ESGNavigationUI} />
              {
                <>
                  <Route path="/" component={ESGNavigationUI} />
                </>
              }
            </Switch>
          </Router>
        </>
      );
    }
    auth.signinRedirect();
    return  <div>not authenticated</div>;
};

export default App;


