import { render, screen, cleanup } from "@testing-library/react";
import PageHeader from "../../common/PageHeader";

afterEach(() => {
  cleanup();
});

test("test collection page header text", () => {
  render(<PageHeader heading="Collection" testId="collection-header" />);
  const h1Element = screen.getByTestId("collection-header");
  expect(h1Element).toHaveTextContent("Collection");
});
