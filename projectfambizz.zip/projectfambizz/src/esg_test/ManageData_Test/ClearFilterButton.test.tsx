import { render, screen, cleanup } from "@testing-library/react";
import ClearFilterButton from "../../containers/ManageData/Collection/ClearFilterButton";

afterEach(() => {
  cleanup();
});

test("test clear button text", () => {
  render(<ClearFilterButton testId="clear-button-collection" />);
  const buttonElement = screen.getByTestId("clear-button-collection");
  expect(buttonElement).toBeInTheDocument();
});
