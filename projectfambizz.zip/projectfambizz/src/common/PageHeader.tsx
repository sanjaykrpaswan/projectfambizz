export const PageHeader = (props: any) => (
  <h1 className="esg-page-heading" data-testid={props.testId}>
    {props.heading}
  </h1>
);
export default PageHeader;
