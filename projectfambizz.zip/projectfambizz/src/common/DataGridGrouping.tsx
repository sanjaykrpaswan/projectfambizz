import { FC, useState } from "react";
import Card from "reactstrap/lib/Card";
import {
  Column,
  DataGrid,
  FilterRow,
  Grouping,
  GroupPanel,
  HeaderFilter,
  Pager,
  Paging,
} from "devextreme-react/data-grid";
import { dxReactGrid } from "navex-react";
import "../styles/styles.css";
import "devextreme/dist/css/dx.light.css";

const { TableHeaderNavbar, HiddenColumnChooserModal, ResetGridModal } =
  dxReactGrid;

interface IColumnExtension {
  columnName: string;
  togglingEnabled: boolean;
}

interface GroupingProps {
  columns: any;
  gridTitle?: string;
  gridData: any;
  isHeaderBar?: boolean;
  isFilterRow?: boolean;
  isHeaderFilter?: boolean;
}

const defaultHiddenColumnNames = ["created"];
const ColumnExtensions: IColumnExtension[] = [
  { columnName: "Asset Id", togglingEnabled: false },
];

export const DataGridGrouping = ({
  columns,
  gridTitle,
  gridData,
  isHeaderBar,
  isFilterRow,
  isHeaderFilter,
}: GroupingProps) => {
  const [resetGridModal, setResetGridModal] = useState(false);
  const [columnChooserModal, setColumnChooserModal] = useState(false);
  const [hiddenColumnNames, setHiddenColumnNames] = useState(
    defaultHiddenColumnNames
  );

  //set column when we choose in setings
  const toggleColumnChooserModal = () => {
    setColumnChooserModal(!columnChooserModal);
  };

  //defined setting menu items
  const settingsMenuItems: any[] = [
    {
      value: "column_selection",
      onClick: () => {
        toggleColumnChooserModal();
      },
      displayText: "Show/Hide Columns",
    },
    {
      value: "reset",
      onClick: () => {
        toggleResetGridModal();
      },
      displayText: "Reset to Default",
    },
  ];

  //Handle click for Reset in setting menu
  const toggleResetGridModal = () => {
    setResetGridModal(!resetGridModal);
  };

  //Handle reset Grid data
  const resetGridStateToDefault = () => {};

  //Handle hidden column model changes
  const setHiddenColumnsNames = (_hiddenColumnNames: string[]) => {
    setHiddenColumnNames(_hiddenColumnNames);
  };

  let title = (
    <div className="parenttitle">
      <div className="titlename">{gridTitle}</div>
    </div>
  );

  //Render  colums
  const renderHeaders = (items: any) => {
    return (
      !hiddenColumnNames.includes(items.name) && (
        <Column
          dataField={items.name}
          caption={items.title}
          alignment={"left"}
          key={items.name}
        />
      )
    );
  };

  return (
    <>
      <Card className="dx-nsg-react-grid survey-table-root dataGrid-card-noheader">
        <div className="card-header" />
        {isHeaderBar && (
          <>
            <ResetGridModal
              isOpen={resetGridModal}
              toggle={toggleResetGridModal}
              onResetGrid={resetGridStateToDefault}
            />
            <TableHeaderNavbar
              tableTitle={title}
              addShow={true}
              settingsMenu={settingsMenuItems}
              settingsMenuToolTip="Settings"
            />
            <HiddenColumnChooserModal
              isOpen={columnChooserModal}
              toggle={toggleColumnChooserModal}
              tableColumns={columns}
              hiddenColumns={hiddenColumnNames}
              columnExtensions={ColumnExtensions}
              onColumnVisibleChange={setHiddenColumnsNames}
            />
          </>
        )}
        <DataGrid
          id="gridContainerGrouping"
          dataSource={gridData}
          className="esg-datagrid header-max-width"
          showBorders={false}
          showColumnLines={false}
          showRowLines={true}
          rowAlternationEnabled={true}
          columnAutoWidth={true}
        >
          <GroupPanel visible={true} />
          <Grouping autoExpandAll={false} />
          <Paging defaultPageSize={10} />
          <Pager visible={true} showInfo={true} showNavigationButtons={true} />
          <FilterRow visible={isFilterRow} />
          <HeaderFilter visible={isHeaderFilter} />
          {columns &&
            columns.map((items: any) => renderHeaders(items))}
        </DataGrid>
      </Card>
    </>
  );
};
export default DataGridGrouping;
