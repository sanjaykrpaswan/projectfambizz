export const RESPONSE_STATUS = {
  success: 200,
  notFound: 404,
  badRequest: 400,
  forbidden: 403,
  unauthorised: 401,
  internalServerError: 500,
  serviceUnavailable: 503,
  gatewayTimeout: 504,
};
