import { FC } from "react";
import { Input } from "navex-react";

export const SearchInput: FC<any> = (props: any) => {
  return (
    <>
      <Input
        id={props.id}
        label={props.label}
        placeholder={props.placeholder}
        buttonText={props.searchIcon}
        buttonLabel={props.buttonLabel}
        buttonProps={{ title: props.label }}
        enableClearX={true}
        clearXTitle=" "
        buttonClickedCallback={props.filterData}
        onChange={(e) => {
          if (e.currentTarget.value === "") {
            props.filterData(e.currentTarget.value);
          }
        }}
        // value={searchField}
      />
    </>
  );
};
export default SearchInput;
