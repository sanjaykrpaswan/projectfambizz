import React, { FC } from 'react'
import { LoadingSpinner, ILoadingSpinnerProps } from 'navex-react/lib/loading'

interface IKnobsInput extends ILoadingSpinnerProps {}
export const Loader: FC<IKnobsInput> = (props) => <LoadingSpinner {...props} />
{   
    <div className="loading-panel">
    <div className="loader" title="Loading..." ></div>
    <span className="sr-only">loading</span>
    </div>
    
    
}
export default Loader;