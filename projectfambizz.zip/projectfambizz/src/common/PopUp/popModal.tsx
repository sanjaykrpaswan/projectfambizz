import React, { FC, useState } from "react";
import { Modal, IModalProps } from "navex-react/lib/modal";
import { Button } from "navex-react/lib/buttons";
import { NewLineToBr } from "navex-react/lib/newLineToBr";

export interface IKnobsInput extends Omit<IModalProps, "show"> {}

const LiveExampleContent: FC<any> = ({ message, ...modalProps }) => {

  return (
    <>
      <Modal
        {...modalProps}
        closeButtonProps={{
          "aria-describedby": "modal-description",
        }}
        headerText={modalProps.modalHeading}
        okButtonText={modalProps.okButtonText}
        cancelButtonText={modalProps.cancelButtonText}
        modalType="PRIMARY"
        show={modalProps.showModal}
        message={message}
        onClickedOk={modalProps.handleClickedOk}
        onClickedCancel={modalProps.handleClickedCancel}
      />
    </>
  );
};
export default LiveExampleContent;