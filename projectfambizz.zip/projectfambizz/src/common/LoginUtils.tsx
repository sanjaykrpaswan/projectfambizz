
export function getredirectUri() {
  let host = window.location.hostname;
  let path = window.location.pathname;

  let tenant = host.split(".")[0];
  if (
    tenant == "stage" ||
    tenant == "lab" ||
    tenant == "csrware" ||
    tenant == "dr"
  ) {
    return window.location.href;
  }

  if (tenant == "localhost") {
    if (path.split("/esg")[1] == "/") {
      return window.location.href + "csrtenant";
    } else if (path.split("/esg")[1] == "") {
      return window.location.href + "/" + "csrtenant";
    } else {
      return window.location.href;
    }
  }

  let server = host.split(".")[1];

  if (server == "csrware") {
    return "https://csrware.com/esg/" + tenant;
  } else {
    return "https://" + server + ".csrware.com/esg/" + tenant;
  }
}

export function getTenantAccountName() {
  let host = window.location.hostname;
  let path = window.location.pathname;
  let tenant = host.split(".")[0];
  if (
    tenant == "stage" ||
    tenant == "lab" ||
    tenant == "csrware" ||
    tenant == "dr" ||
    tenant == "localhost"
  ) {
    tenant = path.split("/esg")[1].split("/")[1];
  }
  if (tenant == undefined || tenant == "") {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get("tenantName");
    if (myParam != undefined || myParam != null) {
      tenant = myParam;
    } else {
      tenant = "csrtenant";
    }
  }
  localStorage.setItem("tanentName", tenant);
  return tenant;
}
