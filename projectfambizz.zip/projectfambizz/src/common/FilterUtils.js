
//Util to filter array of objects based on a object's perticular key
export function getFilteredDataOnKey(data, searchText, key) {
  const filteredData = data.filter((d) =>
    d[key].toLocaleLowerCase().includes(searchText.trim().toLocaleLowerCase())
  );
  return filteredData;
}

//Util to filter array of objects based on all the keys of object
export function getFilteredDataByAnyKey(data, searchText) {
  return data.filter((o) =>
    Object.keys(o).some((k) =>
      o[k].toLowerCase().includes(searchText.trim().toLowerCase())
    )
  );
}
