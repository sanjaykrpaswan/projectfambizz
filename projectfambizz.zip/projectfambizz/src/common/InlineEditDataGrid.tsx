import { useState } from "react";
import Card from "reactstrap/lib/Card";
import {
  Column,
  DataGrid,
  FilterRow,
  Editing,
  HeaderFilter,
  Pager,
  Paging,
  Toolbar,
  Item,
} from "devextreme-react/data-grid";
import { dxReactGrid } from "navex-react";
import "../styles/styles.css";
import "devextreme/dist/css/dx.light.css";

const { TableHeaderNavbar, HiddenColumnChooserModal, ResetGridModal } =
  dxReactGrid;

interface IColumnExtension {
  columnName: string;
  togglingEnabled: boolean;
}

interface GroupingProps {
  columns: any;
  gridTitle?: string;
  gridData: any;
  isHeaderBar?: boolean;
  isFilterRow?: boolean;
  isHeaderFilter?: boolean;
  allowUpdate?: boolean;
  allowDelete?: boolean;
  allowAdd?: boolean;
  onSave: any;
  showOnlyAdd?: boolean;
  resetGridStateToDefault?: any;
}

const defaultHiddenColumnNames = [" "];
const ColumnExtensions: IColumnExtension[] = [
  { columnName: " ", togglingEnabled: false },
];

export const InlineEditDataGrid = ({
  columns,
  gridTitle,
  gridData,
  isHeaderBar,
  isFilterRow,
  isHeaderFilter,
  allowUpdate,
  allowDelete,
  allowAdd,
  onSave,
  showOnlyAdd,
  resetGridStateToDefault,
}: GroupingProps) => {
  const [resetGridModal, setResetGridModal] = useState(false);
  const [columnChooserModal, setColumnChooserModal] = useState(false);
  const [hiddenColumnNames, setHiddenColumnNames] = useState(
    defaultHiddenColumnNames
  );

  let grid: any = null;

  //set column when we choose in setings
  const toggleColumnChooserModal = () => {
    setColumnChooserModal(!columnChooserModal);
  };

  //defined setting menu items
  const settingsMenuItems: any[] = [
    {
      value: "column_selection",
      onClick: () => {
        toggleColumnChooserModal();
      },
      displayText: "Show/Hide Columns",
    },
    {
      value: "reset",
      onClick: () => {
        toggleResetGridModal();
      },
      displayText: "Reset to Default",
    },
  ];

  //Handle click for Reset in setting menu
  const toggleResetGridModal = () => {
    setResetGridModal(!resetGridModal);
  };

  //Handle hidden column model changes
  const setHiddenColumnsNames = (_hiddenColumnNames: string[]) => {
    setHiddenColumnNames(_hiddenColumnNames);
  };

  let title = (
    <div className="parenttitle">
      <div className="titlename">{gridTitle}</div>
    </div>
  );

  //Render  colums
  const renderHeaders = (items: any) => {
    return (
      !hiddenColumnNames.includes(items.name) && (
        <Column
          dataField={items.name}
          caption={items.title}
          alignment={"left"}
          key={items.name}
        />
      )
    );
  };

  //Grid add row instance called
  const addRow = () => {
    grid.instance.addRow();
  };

  return (
    <>
      <Card className="dx-nsg-react-grid survey-table-root dataGrid-card-noheader">
        <div className="card-header" />
        {isHeaderBar && (
          <>
            <ResetGridModal
              isOpen={resetGridModal}
              toggle={toggleResetGridModal}
              onResetGrid={resetGridStateToDefault}
            />
            {showOnlyAdd && !allowAdd ? (
              <TableHeaderNavbar tableTitle={title} addShow={true} />
            ) : showOnlyAdd && allowAdd ? (
              <TableHeaderNavbar
                tableTitle={title}
                addShow={true}
                addButton={{
                  tooltip: "Add Data",
                  menuItems: [{ text: "Add Row", onClick: () => addRow() }],
                }}
              />
            ) : (
              <TableHeaderNavbar
                tableTitle={title}
                addShow={true}
                settingsMenu={settingsMenuItems}
                settingsMenuToolTip="Settings"
                addButton={{
                  tooltip: "Add Data",
                  menuItems: [{ text: "Add Row", onClick: () => addRow() }],
                }}
              />
            )}

            <HiddenColumnChooserModal
              isOpen={columnChooserModal}
              toggle={toggleColumnChooserModal}
              tableColumns={columns}
              hiddenColumns={hiddenColumnNames}
              columnExtensions={ColumnExtensions}
              onColumnVisibleChange={setHiddenColumnsNames}
            />
          </>
        )}
        <DataGrid
          id="gridContainerEditing"
          dataSource={gridData}
          className="esg-datagrid header-max-width"
          ref={(ref) => {
            grid = ref;
          }}
          showBorders={false}
          showColumnLines={false}
          showRowLines={true}
          rowAlternationEnabled={true}
          columnAutoWidth={true}
          onSaving={onSave}
        >
          <Editing
            mode="row"
            editColumnName="Action"
            allowUpdating={allowUpdate}
            allowDeleting={allowDelete}
            useIcons
          />
          <Paging defaultPageSize={10} />
          <Pager visible={true} showInfo={true} showNavigationButtons={true} />
          <FilterRow visible={isFilterRow} />
          <HeaderFilter visible={isHeaderFilter} />
          {columns && columns.map((items: any) => renderHeaders(items))}
        </DataGrid>
      </Card>
    </>
  );
};
export default InlineEditDataGrid;
