import moment from 'moment';

export function getFormattedDateTime(str) {
    if (!str) {
        return "";
    }
    let date = new Date(str);
    let formatdate = moment(date).format(process.env.REACT_APP_FILE_DATE_FORMAT)
    return formatdate
}

export function getFormattedDate(str) {
    if (!str) {
        return "";
    }
    let date = new Date(str);
    let formatdate = moment(date).format(process.env.REACT_APP_DATE_FORMAT)
    return formatdate
}