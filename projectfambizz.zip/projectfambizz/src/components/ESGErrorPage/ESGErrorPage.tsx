import { Col, Row } from "reactstrap";
import "./ESGErrorPage.css";

const ESGErrorPage = (props: any) => {
  return (
    <>
      <h1 className="esg-page-heading">
        <img src="/esg/esg_logo.svg" alt="logo" />
      </h1>
      <hr className="line" />

      <div className="all-page-container lineH-18">
        <h3>
          {"Navex ESG experienced an unexpected error. Please try again later"}
        </h3>
        <Row className="info-detail">
          <Col size={12} sm={2} className="info-label">
            Status Code:{" "}
          </Col>
          <Col size={12} sm={9}>
            {props.errorCode ? props.errorCode : "403"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Error Message:{" "}
          </Col>
          <Col size={12} sm={9}>
            {props.errorMessage ? props.errorMessage : "Forbidden"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Server:{" "}
          </Col>
          <Col size={12} sm={9}>
            {props.server ? props.server : "Unknown"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Requested URI:{" "}
          </Col>
          <Col size={12} sm={9}>
            {props.uri ? props.uri : "JS error"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Date:{" "}
          </Col>
          <Col size={12} sm={9}>
            {new Date().toString()}
          </Col>
        </Row>
        <div className="support-text">
          If the error continues to occur, please contact support at{" "}
          <a href="mailto:navexesg@navex.com">navexesg@navex.com</a>
        </div>
        <div className="login-foot-info">
          © 2022 NAVEX, Inc. All Rights Reserved.
        </div>
      </div>
    </>
  );
};

export default ESGErrorPage;
