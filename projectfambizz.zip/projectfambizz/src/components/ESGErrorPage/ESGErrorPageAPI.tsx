import { Col, Row } from "reactstrap";
import "./ESGErrorPage.css";

const ESGErrorPageAPI = (props: any) => {
  const { location } = props;

  const getMsgFromCode = (code: any) => {
    switch (code) {
      case 406:
        return "Not Acceptable - invalid header sent in the request";
      case 409:
        return "Conflict - The request could not be completed due to a conflict with the current state of the resource";
      case 401:
        return "Unauthorized – The request cannot be fulfilled until your user account has been granted sufficient privileges.Your account is most likely not setup with rights to perform this action.";
      case 403:
        return "Forbidden – The request cannot be fulfilled until your user account is authorized.";
      case 404:
        return (
          <span>
            Resource Not Found – he server has not found anything matching the
            Request-URI.
            <ul>
              Possible causes:<li>Broken link</li>
              <li>Incorrect URL</li>
            </ul>
          </span>
        );
      case 405:
        return "Method Not Allowed – The method specified in the Request-Line is not allowed for the resource identified by the Request-URI.Most likely we broke something recently.";
      case 504:
        return "Gateway Timeout Error - Our server encountered a Timeout Error which prevented it from fulfilling the request.Please try loging after sometime.";
      default:
        return "Internal Server Error - Our server encountered an unexpected condition which prevented it from fulfilling the request.Most likely we broke something recently.";
    }
  };

  return (
    <>
      <h1 className="esg-page-heading">Application Error</h1>
      <hr className="line" />

      <div className="all-page-container lineH-18">
        <h3>
          {"Navex ESG experienced an unexpected error. Please try again later"}
        </h3>
        <Row className="info-detail">
          <Col size={12} sm={2} className="info-label">
            Status Code:{" "}
          </Col>
          <Col size={12} sm={9}>
            {location?.state?.errorCode ? location.state.errorCode : "403"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Error Message:{" "}
          </Col>
          <Col size={12} sm={9}>
            {location?.state?.errorCode &&
              getMsgFromCode(location.state.errorCode)}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Server:{" "}
          </Col>
          <Col size={12} sm={9}>
            {location?.state?.server ? location.state.server : "Unknown"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Requested URI:{" "}
          </Col>
          <Col size={12} sm={9}>
            {location?.state?.uri ? location.state.uri : "JS error"}
          </Col>
        </Row>
        <Row>
          <Col size={12} sm={2} className="info-label">
            Date:{" "}
          </Col>
          <Col size={12} sm={9}>
            {new Date().toString()}
          </Col>
        </Row>
        <div className="support-text">
          If the error continues to occur, please contact support at{" "}
          <a href="mailto:navexesg@navex.com">navexesg@navex.com</a>
        </div>
        <div className="login-foot-info">
          © 2022 NAVEX, Inc. All Rights Reserved.
        </div>
      </div>
    </>
  );
};

export default ESGErrorPageAPI;
