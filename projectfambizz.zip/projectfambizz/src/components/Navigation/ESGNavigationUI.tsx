import React, { useEffect, FC } from "react";
import {
  faHome,
  faCog,
  faPowerOff,
  faBullhorn,
  faListAlt,
  faChartLine,
} from "@fortawesome/free-solid-svg-icons";
import { AppNavigationUI, IAppNavigationUIRoute } from "navex-react";
import { DefaultPage } from "navex-react/lib/pageTemplates";

import { PlatformTopNavContainer } from "./PlatformTopNavContainer";
import { history } from "../../services/UseHistory";
import LandingPage from "../../containers/LandingPage/LandingPage";
import Disclose from "../../containers/Disclose/Disclose";
import Analyze from "../../containers/Analyze/Analyze";
import Units from "../../containers/Settings/Units/Units";
import Collection from "../../containers/ManageData/Collection/Collection";
import ViewUnits from "../../containers/Settings/Units/ViewUnits";
import CreateUnit from "../../containers/Settings/Units/CreateUnit";
import EditUnit from "../../containers/Settings/Units/EditUnit";
import ViewResourceType from "../../containers/Settings/ResourceType/ViewResourcetype";
import EditResourceType from "../../containers/Settings/ResourceType/EditResourceType";
import CreateResourceType from "../../containers/Settings/ResourceType/CreateResourceType";
import ResourceType from "../../containers/Settings/ResourceType/ResourceType";
import UnitGroups from "../../containers/Settings/UnitGroups/UnitGroups"
import ViewUnitGroup from "../../containers/Settings/UnitGroups/ViewUnitGroup"
import Currency from "../../containers/Settings/Currency/Currency";
import EditCurrency from "../../containers/Settings/Currency/EditCurrency";
import ViewCurrency from "../../containers/Settings/Currency/ViewCurrency";
import CreateCurrency from "../../containers/Settings/Currency/CreateCurrency";
import CreateUnitGroup from "../../containers/Settings/UnitGroups/CreateUnitGroup";
import EditUnitGroup from "../../containers/Settings/UnitGroups/EditUnitGroup";
import Category from "../../containers/Settings/Category/AssetCategory";
import EditAsset from "../../containers/ManageData/Collection/EditAsset";
import ViewAsset from "../../containers/ManageData/Collection/ViewAsset";
import EditAssetcategory from "../../containers/Settings/Category/EditAssetCategory";





const SignOutContent = () => {
  useEffect(() => {
    //UserService.doLogout();
  }, []);
  return <DefaultPage>Logging out of all Navex applications...</DefaultPage>;
};

const userMenuRoutes: IAppNavigationUIRoute[] = [
  {
    id: "route_signout",
    title: "Sign Out",
    path: "/signout",
    icon: faPowerOff,
    component: SignOutContent,
  },
];

/** Visit the **Knobs** tab to interact with these props */
interface IKnobsInput {
  appName?: string;
  backToGatewayUrl?: string;
  waffleEnabled?: boolean;
  userMenuDisplayName?: string;
  altHeader: boolean;
}

const ESGNavigationUI: FC<IKnobsInput> = (props) => {
  const sideMenuRoutes: IAppNavigationUIRoute[] = [
    {
      id: "landingPage",
      title: "My ESG",
      path: `/esg/${localStorage.getItem("tanentName")}`,
      aliasPaths: ["/esg", `/esg/${localStorage.getItem("tanentName")}`],
      icon: faHome,
      component: LandingPage,
    },
    {
      id: "manageData",
      title: "Manage Data",
      // path: `/esg/${localStorage.getItem("tanentName")}/manageData`,
      icon: faListAlt,
      subRoutes: [
        {
          id: "collection",
          title: "Collection",
          path: `/esg/${localStorage.getItem(
            "tanentName"
          )}/datacollection/collection`,
          //icon: faDesktop,
          component: Collection,
        },
      ],
    },
    {
      id: "disclose",
      title: "Disclose",
      path: `/esg/${localStorage.getItem("tanentName")}/disclose`,
      icon: faBullhorn,
      component: Disclose,
    },
    {
      id: "analyze",
      title: "Analyze",
      path: `/esg/${localStorage.getItem("tanentName")}/analyze`,
      icon: faChartLine,
      component: Analyze,
    },
    {
      id: "settings",
      title: "Settings",
      icon: faCog,
      
      subRoutes: [
        {
          id: "resourceType",
          title: "Resource Type",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/resourceType`,
          component: ResourceType,
        },
        // {
        //   id: "units",
        //   title: "Units",
        //   path: `/esg/${localStorage.getItem("tanentName")}/settings/units`,
        //   component: Units,
        // },
        {

          id: "unitgroups",
          title: "Unit Groups",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups`,
          component: UnitGroups,
        },

       {
          id: "currency",
          title: "Currency",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/currency`,
          component: Currency,
        },
        {
          id:"category",
          title:"Asset Category",
          path:`/esg/${localStorage.getItem("tanentName")}/settings/assetCategory`,
          component:Category,
        }

       
      ],
    },
  ];

  return (
    <AppNavigationUI
      id="app_shell"
      appName={props.appName}
      backToGatewayEnabled={false}
      backToGatewayUrl={"true"}
      waffleEnabled={false}
      wafflePuid={"platform_user_id"} // This is not a real id, you will need to get one.
      waffleLanguage={"en"}
      userMenuDisplayName={props.userMenuDisplayName}
      headerLogoSrc="/esg/esg_logo.svg"
      headerContents={<PlatformTopNavContainer />}
      userMenuEnabled={false}
      userMenuRoutes={userMenuRoutes}
      altHeader={true}
      sideMenuRoutes={sideMenuRoutes}
      historyOverride={history}
      otherRoutes={[

        {

          id: "viewUnits",
          title: "View Units",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/units/viewUnits`,
          component: ViewUnits
        },
        {
          id: "viewResourceType",
          title: "View ResourceType",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/resourceType/viewResourceType`,
          component: ViewResourceType
            
        },
        {
          id: "viewUnitGroup",
          title: "View UnitGroup",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/viewUnitGroup`,
          component: ViewUnitGroup

        },
        {

          id: "viewUnits",
          title: "View Units",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/units/viewUnit`,
          component: ViewUnits
        },
        {
          id: "editUnit",
          title: "Edit Unit",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/units/editUnit`,
          component: EditUnit
        },
        {
          id: "newUnit",
          title: "New Unit",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/units/addUnit`,
          component: CreateUnit
        },
        {

          id: "editResourceType",
          title: "Edit ResourceType",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/resourceType/editResourceType`,
          component: EditResourceType
        },
        {
          id: "newResourceType",
          title: "New ResourceType",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/resourceType/newResourceType`,
          component: CreateResourceType
        },
        {
          id: "newCurrency",
          title: "New Currency",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/currency/addCurrency`,
          component: CreateCurrency
        },
        {
          id: "editCurrency",
          title: "Edit Currency",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/currency/editCurrency`,
          component: EditCurrency
        },
        {
          id: "viewCurrency",
          title: "View Currency",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/currency/viewCurrency`,
          component: ViewCurrency
        },
        {
          id: "newUnitGroup",
          title: "New Unit Group",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/newUnitGroup`,
          component: CreateUnitGroup
        }, 
        {
          id: "editUnitGroup",
          title: "Edit Unit Group",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/unitGroups/editUnitGroup`,
          component: EditUnitGroup
        },
        {
          id: "editAsset",
          title: "Edit Asset",
          path: `/esg/${localStorage.getItem("tanentName")}/datacollection/collection/editAsset`,
          component: EditAsset
        },
        {
          id: "viewAsset",
          title: "View Asset",
          path: `/esg/${localStorage.getItem("tanentName")}/datacollection/collection/viewAsset`,
          component: ViewAsset
        },
        {
          id: "editAssetCategory",
          title: "Edit Asset Category",
          path: `/esg/${localStorage.getItem("tanentName")}/settings/assetCategory/editAssetCategory`,
          component: EditAssetcategory
        }

      ]}
  />

)
};

export default ESGNavigationUI;
