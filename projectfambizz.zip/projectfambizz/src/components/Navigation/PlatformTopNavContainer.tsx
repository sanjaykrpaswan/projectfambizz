import React, { useEffect } from 'react';
import { useAuth } from 'react-oidc-context';
import { loadScript } from '../../services/loadScript';
import { IPlatformTopNavOptions } from './IPlatformTopNavOptions';


declare const Navex: any


export const PlatformTopNavContainer = (props:any) => {
  const divId = 'platform-top-nav'
  const auth = useAuth();
  useEffect(() => {

    injectPlatformTopNav()

  }, // eslint-disable-next-line
    [])

  const injectPlatformTopNav = async () => {
    let url = process.env.REACT_APP_PLATFORM_TOP_NAV_SCRIPT_URL
    await loadScript('platform-top-nav-script', url == undefined ? '' : url)
    const platformTopNavOptions: IPlatformTopNavOptions = {
        divId,
        clientKey: auth.settings.client_id,
        lang: auth.user?.profile.locale,
        puid: auth.user?.profile.puid,
        showTasks: false,
        devMode: false,
        onClickedSignout: () => {
            //UserService.doLogout();
            auth.signoutRedirect();
        },
        onGetAuthTokenFromHostApp: function (): string | Promise<string> | undefined {
           // throw new Error('Function not implemented.');
            return auth.user?.access_token;
        }
    }
    Navex.PlatformTopNav.inject(platformTopNavOptions)
  }

  return (
    <div id={divId}></div>
  )
}