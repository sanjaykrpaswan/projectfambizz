// This should match the interface from here:
// https://github.com/tnwinc/platform-top-nav/edit/develop/src/interfaces/IPlatformTopNavOptions.d.ts
export interface IPlatformTopNavOptions {
    // Required props
    divId: string
    puid: any
    lang: any
    clientKey: any
    onGetAuthTokenFromHostApp: () => string | Promise<string> | undefined
  
    // Optional props
    applicationSettingsUrl?: string
    onClickedApplicationSettings?: (e: any) => void
    helpUrl?: string
    onClickedHelp?: (e: any) => void
    signoutUrl?: string
    onClickedSignout?: (e: any) => void
    showTasks?: boolean
    showWaffleButton?: boolean
    onUserDetailsChanged?: (userDetails: any) => void
    devMode: any
    showWaffleIcon?: boolean 
  }