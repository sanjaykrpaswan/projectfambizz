import React from 'react'
import { DefaultPage } from 'navex-react/lib/pageTemplates'

export default class extends React.Component {
  render() {
    return (
      <DefaultPage>
        <p>This page loaded lazily</p>
      </DefaultPage>
    )
  }
}